#!/usr/bin/env python3
# ai_predict_train_tft_ctk.py

# BSD-C-3 License

import setproctitle
setproctitle.setproctitle("ai_predict_train_tft_ctk")

import customtkinter as ctk
from customtkinter import CTk, CTkFrame, CTkLabel, CTkButton, CTkEntry, CTkTextbox
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import multiprocessing
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import pickle
import json
import gc
import psutil
from datetime import datetime
from sklearn.preprocessing import StandardScaler
import traceback
import sys
import os
import time
import tempfile
import shutil
import warnings

# Force spawn method to avoid fork issues with CUDA
try:
    multiprocessing.set_start_method('spawn', force=True)
except RuntimeError:
    pass  # Already set

import lightning.pytorch as pl
from lightning.pytorch.callbacks import EarlyStopping, ModelCheckpoint
from pytorch_forecasting import (
    TimeSeriesDataSet,
    TemporalFusionTransformer,  # Fixed: removed the alias
    RMSE,
)

# Suppress FutureWarnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# ===== Configuration Class =====
class Config:
    """Central configuration for all settings"""

    # Paths
    HOME = Path.home()
    MODEL_DIR = HOME / "ai_models"
    DATASET_DIR = HOME / "mt5_data"

    # Data settings
    MAX_ROWS_PER_SYMBOL = 5000
    MAX_DATASET_ROWS = 100000
    DEFAULT_FEATURES = ['time', 'open', 'high', 'low', 'close', 'volume']

    # Model settings
    DEFAULT_LOOKBACK = 60       # Increased for better temporal patterns
    DEFAULT_HORIZON = 10
    DEFAULT_EPOCHS = 30
    DEFAULT_BATCH_SIZE = 512    # Increased for stability
    DEFAULT_HIDDEN_SIZE = 64    # Increased for better learning
    DEFAULT_NUM_HEADS = 4
    DEFAULT_NUM_LAYERS = 2
    DROPOUT_RATE = 0.2          # Increased for regularization

    # Training settings
    EARLY_STOPPING_PATIENCE = 10
    LEARNING_RATE = 0.0005      # Lower for stability
    WEIGHT_DECAY = 1e-5         # Lower weight decay
    GRADIENT_CLIP_NORM = 1.0

    # Memory settings
    MEMORY_WARNING_THRESHOLD_GB = 0.5
    STREAM_CHUNK_SIZE = 5000
    MAX_MEMORY_FOR_SEQUENCES_GB = 2.0

    # Number of chunks reserved from the stream to build a validation set
    VALIDATION_CHUNKS = 2
    NUM_WORKERS = 0

    # Timeframes
    TIMEFRAMES = ['M5', 'M15', 'H1', 'H4', 'D1', 'W1']

    # UI settings
    APP_TITLE = "🤖 TFT Model Trainer"
    APP_GEOMETRY = "640x1100"  # Slightly taller for UsageRow
    THEME = "dark"
    COLOR_THEME = "dark-blue"

    @classmethod
    def ensure_directories(cls):
        cls.MODEL_DIR.mkdir(parents=True, exist_ok=True)
        cls.DATASET_DIR.mkdir(parents=True, exist_ok=True)

Config.ensure_directories()

# ===== CTK Theme Settings =====
ctk.set_appearance_mode(Config.THEME)
ctk.set_default_color_theme(Config.COLOR_THEME)

# ===== Constants =====
HOME = Config.HOME
MODEL_DIR = Config.MODEL_DIR
DATASET_DIR = Config.DATASET_DIR

# ===== GPU Manager =====
class GPUManager:
    def __init__(self, verbose=True):
        self.verbose = verbose
        self.gpu_available = False
        self.gpu_info = {}
        self.gpu_memory_gb = 0
        self.device = None
        self._detect_gpu()

    def _log(self, message):
        if self.verbose:
            print(f"[GPUManager] {message}")

    def _detect_gpu(self):
        self.gpu_available = torch.cuda.is_available()
        if self.gpu_available:
            try:
                # Initialize CUDA properly
                torch.cuda.init()
                torch.cuda.set_device(0)

                device_count = torch.cuda.device_count()
                self.gpu_info['device_count'] = device_count
                for i in range(device_count):
                    props = torch.cuda.get_device_properties(i)
                    mem_gb = props.total_memory / 1e9
                    self.gpu_info[f'device_{i}'] = {
                        'name': props.name,
                        'memory_gb': mem_gb,
                        'compute_capability': f"{props.major}.{props.minor}"
                    }
                    self.gpu_memory_gb = mem_gb
                self.device = torch.device('cuda:0')
                # Warm up CUDA
                torch.zeros(1).cuda()
                self._log(f"✅ GPU detected: {self.gpu_info['device_0']['name']}")
            except Exception as e:
                self._log(f"❌ Error detecting GPU: {e}")
                self.gpu_available = False
                self.device = torch.device('cpu')
        else:
            self.device = torch.device('cpu')
            self._log("ℹ️ No GPU detected, using CPU")

    def get_device(self, framework='pytorch'):
        return self.device if framework == 'pytorch' else None

    def optimize_for_gpu(self):
        if not self.gpu_available:
            return {'batch_size': 128, 'device': self.device, 'use_amp': False}
        batch_size = 1024 if self.gpu_memory_gb >= 8 else 512
        return {'batch_size': batch_size, 'device': self.device, 'use_amp': self.gpu_available}

# ===== Usage Row Class =====
class UsageRow:
    """System usage monitoring row for the GUI"""

    def __init__(self, parent):
        self.parent = parent
        self.usage_frame = None
        self.usage_label = None
        self._create_usage_row()

    def _create_usage_row(self):
        """Create the usage monitoring row"""
        self.usage_frame = CTkFrame(self.parent, height=40, corner_radius=5)
        self.usage_frame.pack(fill="x", pady=(0, 10))

        self.usage_label = CTkLabel(
            self.usage_frame,
            text="Loading system usage...",
            font=("Ubuntu Mono", 20),
            text_color="Lime"
        )
        self.usage_label.pack(expand=True, fill="x", padx=10, pady=5)

        self._update_usage()

    def _update_usage(self):
        """Update system usage metrics"""
        try:
            # CPU usage
            cpu = psutil.cpu_percent(interval=0.5)

            # RAM usage
            dram = psutil.virtual_memory().percent

            # GPU and VRAM usage (if available)
            gpu_percent = 0
            vram_percent = 0
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_percent = gpu.load * 100
                    vram_percent = gpu.memoryUtil * 100
            except (ImportError, Exception):
                # GPUtil not available or no GPU found
                pass

            # Update label with system stats
            self.usage_label.configure(
                text=f"CPU: {cpu:.1f}%  DRAM: {dram:.1f}%  GPU: {gpu_percent:.1f}%  VRAM: {vram_percent:.1f}%"
            )

        except Exception as e:
            # Fallback if monitoring fails
            self.usage_label.configure(
                text="⚠️ System monitoring unavailable"
            )

        # Schedule next update (every 2 seconds)
        self.usage_label.after(2000, self._update_usage)

# ===== Console Logger =====
class ConsoleLogger:
    def __init__(self, gui_logger, original_stream):
        self.gui_logger = gui_logger
        self.original_stream = original_stream

    def write(self, message):
        if message and message.strip():
            self.original_stream.write(message)
            self.original_stream.flush()
            if self.gui_logger:
                self.gui_logger.log(message.strip(), "console")

    def flush(self):
        self.original_stream.flush()

# ===== Memory Optimizer =====
class MemoryOptimizer:
    @staticmethod
    def get_free_memory_gb():
        if torch.cuda.is_available():
            return (torch.cuda.get_device_properties(0).total_memory - torch.cuda.memory_allocated(0)) / 1e9
        return psutil.virtual_memory().available / 1e9

    @staticmethod
    def get_system_memory_gb():
        return psutil.virtual_memory().total / 1e9

    @staticmethod
    def get_system_memory_available_gb():
        return psutil.virtual_memory().available / 1e9

    @staticmethod
    def clear_cache():
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()

    @staticmethod
    def monitor_memory(threshold_gb=0.5):
        return MemoryOptimizer.get_system_memory_available_gb() < threshold_gb

# ===== Feature Engineer =====
class FeatureEngineer:
    """Extract time-based and technical features"""

    @staticmethod
    def add_time_features(df):
        """Add time-based features from the time column"""
        if 'time' not in df.columns:
            return df

        # Convert time to datetime if needed
        if not pd.api.types.is_datetime64_any_dtype(df['time']):
            df['time'] = pd.to_datetime(df['time'])

        # Time-based features
        df['hour'] = df['time'].dt.hour
        df['day_of_week'] = df['time'].dt.dayofweek  # 0=Monday, 6=Sunday
        df['day_of_month'] = df['time'].dt.day
        df['month'] = df['time'].dt.month
        df['quarter'] = df['time'].dt.quarter
        df['year'] = df['time'].dt.year

        # Cyclical encoding of time features
        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)

        return df

    @staticmethod
    def add_technical_features(df):
        """Add basic technical indicators"""
        # Price-based features
        if all(c in df.columns for c in ['high', 'low', 'close']):
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_high_ratio'] = df['close'] / df['high']
            df['close_low_ratio'] = df['close'] / df['low']

        # Returns
        if 'close' in df.columns:
            df['returns_1'] = df['close'].pct_change()
            df['returns_5'] = df['close'].pct_change(periods=5)
            df['returns_10'] = df['close'].pct_change(periods=10)

        # Volume features
        if 'volume' in df.columns:
            df['volume_ma_5'] = df['volume'].rolling(5).mean()
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(5).mean()

        return df


class GUILogger:
    def __init__(self):
        self.messages = []
        self.log_widget = None
        self.ready = False
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr

    def set_log_widget(self, widget):
        self.log_widget = widget
        self.ready = True
        self.log_widget.configure(font=("Ubuntu Mono", 11))
        for msg, level in self.messages:
            self._write_to_widget(msg, level)
        self.messages.clear()

    def _write_to_widget(self, message, level):
        if self.log_widget:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {message}\n"
            try:
                self.log_widget.insert("end", log_entry)
                self.log_widget.see("end")
                self.log_widget.update_idletasks()
            except:
                print(log_entry, flush=True)

    def log(self, message, level="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_entry = f"[{timestamp}] [{level.upper()}] {message}"
        try:
            self._original_stdout.write(console_entry + "\n")
            self._original_stdout.flush()
        except:
            print(console_entry, flush=True)
        if self.ready and self.log_widget:
            self._write_to_widget(message, level)
        else:
            self.messages.append((message, level))

    def enable_console_redirect(self):
        sys.stdout = ConsoleLogger(self, self._original_stdout)
        sys.stderr = ConsoleLogger(self, self._original_stderr)

    def disable_console_redirect(self):
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr


class StreamingDataPreparer:
    """Builds a PyTorch Forecasting-compatible dataframe."""

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print
        self.feature_cols = []
        self.target_column = "target"
        self.training_dataframe = None
        self.dataset_parameters = None

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def load_csv_data(self, symbol, timeframe, csv_folder):
        csv_file = Path(csv_folder) / symbol / f"{symbol}_{timeframe}.csv"

        if not csv_file.exists():
            return None

        try:
            df = pd.read_csv(csv_file)

            if "time" not in df.columns:
                self._log(f"⚠️ Missing time column: {csv_file}")
                return None

            # Existing files are treated as Unix seconds when numeric.
            if pd.api.types.is_numeric_dtype(df["time"]):
                df["time"] = pd.to_datetime(df["time"], unit="s")
            else:
                df["time"] = pd.to_datetime(df["time"])

            df = (
                df.sort_values("time")
                .drop_duplicates("time")
                .reset_index(drop=True)
            )

            return df

        except Exception as exc:
            self._log(f"❌ Error loading {csv_file}: {exc}")
            return None

    def scan_folder(self, csv_folder):
        csv_folder = Path(csv_folder)

        if not csv_folder.exists():
            return [], []

        symbols = []
        all_timeframes = set()

        for symbol_dir in sorted(csv_folder.iterdir()):
            if not symbol_dir.is_dir():
                continue

            symbol = symbol_dir.name
            found_timeframes = []

            for timeframe in Config.TIMEFRAMES:
                csv_file = symbol_dir / f"{symbol}_{timeframe}.csv"

                if csv_file.exists():
                    found_timeframes.append(timeframe)
                    all_timeframes.add(timeframe)

            if found_timeframes:
                symbols.append((symbol, found_timeframes))
                self._log(
                    f"   ✓ {symbol}: {', '.join(found_timeframes)}"
                )

        return symbols, sorted(all_timeframes)

    def _prepare_single_series(
        self,
        df,
        group_id,
        horizon,
        requested_features,
    ):
        if df is None or len(df) < 100:
            return None

        df = df.copy()

        if len(df) > Config.MAX_ROWS_PER_SYMBOL:
            df = df.iloc[-Config.MAX_ROWS_PER_SYMBOL:].copy()

        df = FeatureEngineer.add_time_features(df)
        df = FeatureEngineer.add_technical_features(df)

        # Features supplied by the GUI are treated as requested base columns.
        # "time" is metadata and is not passed as a numeric model feature.
        requested_features = [
            column for column in requested_features
            if column != "time"
        ]

        engineered_features = [
            "hour_sin",
            "hour_cos",
            "day_sin",
            "day_cos",
            "month_sin",
            "month_cos",
            "high_low_ratio",
            "close_high_ratio",
            "close_low_ratio",
            "returns_1",
            "returns_5",
            "returns_10",
            "volume_ratio",
        ]

        candidate_features = list(dict.fromkeys(
            requested_features + engineered_features
        ))

        available_features = [
            column for column in candidate_features
            if column in df.columns
        ]

        required_columns = ["open", "high", "low", "close", "volume"]
        for column in required_columns:
            if column in df.columns and column not in available_features:
                available_features.append(column)

        if "close" not in df.columns:
            self._log(f"⚠️ Skipping {group_id}: close column unavailable")
            return None

        if not available_features:
            self._log(f"⚠️ Skipping {group_id}: no usable features")
            return None

        # Remove invalid values before creating the target.
        df[available_features] = (
            df[available_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
        )

        df[self.target_column] = df["close"].shift(-horizon)

        df = df.dropna(subset=[self.target_column]).copy()

        if len(df) < Config.DEFAULT_LOOKBACK + horizon + 10:
            return None

        # Each symbol/timeframe is an independent time series.
        df["group_id"] = str(group_id)
        df["time_idx"] = np.arange(len(df), dtype=np.int64)

        # PyTorch Forecasting expects categorical group identifiers.
        df["group_id"] = df["group_id"].astype(str)

        keep_columns = [
            "time",
            "time_idx",
            "group_id",
            self.target_column,
        ] + available_features

        return df[keep_columns], available_features

    def build_dataframe(
        self,
        csv_folder,
        feature_cols,
        horizon=10,
    ):
        """
        Load all symbol/timeframe files into one dataframe.

        Each symbol/timeframe is represented as an independent group_id.
        """
        csv_folder = Path(csv_folder)
        symbols, _ = self.scan_folder(csv_folder)

        if not symbols:
            raise ValueError(f"No symbol/timeframe files found in {csv_folder}")

        frames = []
        all_features = []

        for symbol, timeframes in symbols:
            for timeframe in timeframes:
                group_id = f"{symbol}_{timeframe}"

                df = self.load_csv_data(
                    symbol,
                    timeframe,
                    csv_folder,
                )

                prepared = self._prepare_single_series(
                    df=df,
                    group_id=group_id,
                    horizon=horizon,
                    requested_features=feature_cols,
                )

                if prepared is None:
                    continue

                prepared_df, available_features = prepared
                frames.append(prepared_df)
                all_features.extend(available_features)

                self._log(
                    f"   📊 {group_id}: "
                    f"{len(prepared_df)} rows"
                )

        if not frames:
            raise ValueError("No usable time series were produced")

        all_features = list(dict.fromkeys(all_features))

        result = pd.concat(frames, ignore_index=True, sort=False)

        for column in all_features:
            if column not in result.columns:
                result[column] = 0.0

        result[all_features] = (
            result[all_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
            .astype(np.float32)
        )

        result[self.target_column] = (
            result[self.target_column]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .astype(np.float32)
        )

        result = result.sort_values(
            ["group_id", "time_idx"]
        ).reset_index(drop=True)

        self.feature_cols = all_features
        self.training_dataframe = result

        self._log(
            f"✅ Prepared {len(result):,} rows, "
            f"{result['group_id'].nunique()} independent series"
        )
        self._log(
            f"✅ Numeric features: {len(self.feature_cols)}"
        )

        return result


class StreamingTFTTrainer:
    """
    Trainer backed by the real PyTorch Forecasting TFT.

    This class intentionally does not use the previous manual TensorDataset
    streaming loop. TimeSeriesDataSet owns sequence construction, encoding,
    normalization, and decoder/encoder splitting.
    """

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print

        self.model = None
        self.training_dataset = None
        self.validation_dataset = None
        self.dataset_parameters = None

        self.is_trained = False
        self.stop_flag = False
        self.checkpoint_path = None

        self.gpu_manager = GPUManager(verbose=False)
        self.device = self.gpu_manager.get_device("pytorch")

        self.batch_size = self.gpu_manager.optimize_for_gpu().get(
            "batch_size",
            Config.DEFAULT_BATCH_SIZE,
        )

        self.hidden_size = Config.DEFAULT_HIDDEN_SIZE
        self.attention_head_size = Config.DEFAULT_NUM_HEADS
        self.dropout = Config.DROPOUT_RATE
        self.hidden_continuous_size = max(8, self.hidden_size // 2)

        self.training_history = {
            "train_losses": [],
            "val_losses": [],
            "best_val_loss": float("inf"),
            "epochs_completed": 0,
        }

        self._log(
            f"📱 Real PyTorch Forecasting TFT initialized on: "
            f"{self.device}"
        )

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def stop_training(self):
        self.stop_flag = True
        self._log("⏹️ Training stop requested")

    def _make_dataloader(
        self,
        dataset,
        batch_size,
        train,
    ):
        return dataset.to_dataloader(
            train=train,
            batch_size=batch_size,
            num_workers=Config.NUM_WORKERS,
            pin_memory=torch.cuda.is_available(),
        )

    def train_streaming(
        self,
        data_stream,
        total_samples,
        epochs=30,
        batch_size=512,
        lookback=60,
        horizon=10,
        **kwargs,
    ):
        """
        Train the real TemporalFusionTransformer.

        The GUI still passes data_stream for compatibility, but the actual
        dataset is rebuilt from csv_folder because PyTorch Forecasting needs
        time_idx, group_ids, target columns, and feature-role metadata.
        """
        try:
            self.stop_flag = False

            csv_folder = kwargs.get("csv_folder")
            feature_cols = kwargs.get("feature_cols")

            if csv_folder is None:
                raise ValueError(
                    "csv_folder must be supplied to train_streaming"
                )

            if not feature_cols:
                feature_cols = Config.DEFAULT_FEATURES

            preparer = kwargs.get("data_preparer")

            if preparer is None:
                raise ValueError(
                    "data_preparer must be supplied to train_streaming"
                )

            self._log("📥 Building PyTorch Forecasting dataframe...")

            data = preparer.build_dataframe(
                csv_folder=csv_folder,
                feature_cols=feature_cols,
                horizon=horizon,
            )

            feature_columns = preparer.feature_cols

            if len(data) == 0:
                raise ValueError("Prepared dataframe is empty")

            # Use the latest part of each group for validation.
            group_max = data.groupby("group_id")["time_idx"].transform("max")
            cutoff_by_group = group_max - horizon
            training_data = data[
                data["time_idx"] <= cutoff_by_group
            ].copy()

            if len(training_data) == 0:
                raise ValueError("Training dataframe is empty")

            known_reals = [
                column for column in feature_columns
                if column in {
                    "hour_sin",
                    "hour_cos",
                    "day_sin",
                    "day_cos",
                    "month_sin",
                    "month_cos",
                }
            ]

            unknown_reals = [
                column for column in feature_columns
                if column not in known_reals
            ]

            # Target is intentionally included as a historical unknown real.
            if "close" in unknown_reals:
                pass
            elif "close" in data.columns:
                unknown_reals.append("close")

            self._log("🧱 Creating TimeSeriesDataSet...")

            self.training_dataset = TimeSeriesDataSet(
                training_data,
                time_idx="time_idx",
                target="target",
                group_ids=["group_id"],
                min_encoder_length=lookback,
                max_encoder_length=lookback,
                min_prediction_length=horizon,
                max_prediction_length=horizon,
                static_categoricals=["group_id"],
                time_varying_known_reals=["time_idx"] + known_reals,
                time_varying_unknown_reals=unknown_reals,
                target_normalizer="auto",
                add_relative_time_idx=True,
                add_encoder_length=True,
                allow_missing_timesteps=False,
            )

            self.dataset_parameters = (
                self.training_dataset.get_parameters()
            )

            self.validation_dataset = TimeSeriesDataSet.from_dataset(
                self.training_dataset,
                data,
                predict=False,
                stop_randomization=True,
            )

            train_loader = self._make_dataloader(
                self.training_dataset,
                batch_size=batch_size,
                train=True,
            )

            validation_loader = self._make_dataloader(
                self.validation_dataset,
                batch_size=batch_size,
                train=False,
            )

            self._log(
                f"📊 Training samples: "
                f"{len(self.training_dataset):,}"
            )
            self._log(
                f"📊 Validation samples: "
                f"{len(self.validation_dataset):,}"
            )

            self.model = TemporalFusionTransformer.from_dataset(
                self.training_dataset,
                learning_rate=Config.LEARNING_RATE,
                hidden_size=self.hidden_size,
                attention_head_size=self.attention_head_size,
                dropout=self.dropout,
                hidden_continuous_size=self.hidden_continuous_size,
                output_size=1,
                loss=RMSE(),
                mask_bias=-float("inf"),
                log_interval=-1,
                reduce_on_plateau_patience=4,
            )

            parameter_count = sum(
                parameter.numel()
                for parameter in self.model.parameters()
            )

            self._log(
                f"🧠 Real TFT parameters: {parameter_count:,}"
            )

            accelerator = "gpu" if self.device.type == "cuda" else "cpu"
            devices = 1

            precision = (
                "16-mixed"
                if accelerator == "gpu"
                else "32-true"
            )

            checkpoint_callback = ModelCheckpoint(
                dirpath=str(Config.MODEL_DIR),
                filename="tft-best-{epoch:02d}-{val_loss:.5f}",
                monitor="val_loss",
                mode="min",
                save_top_k=1,
                save_last=True,
            )

            early_stopping = EarlyStopping(
                monitor="val_loss",
                min_delta=0.0,
                patience=Config.EARLY_STOPPING_PATIENCE,
                mode="min",
                verbose=True,
            )

            lightning_trainer = pl.Trainer(
                accelerator=accelerator,
                devices=devices,
                max_epochs=epochs,
                min_epochs=1,
                precision=precision,
                gradient_clip_val=Config.GRADIENT_CLIP_NORM,
                callbacks=[
                    checkpoint_callback,
                    early_stopping,
                ],
                logger=False,
                enable_progress_bar=False,
                enable_model_summary=False,
                num_sanity_val_steps=0,
            )

            self._log("🚀 Starting real TFT training...")

            lightning_trainer.fit(
                self.model,
                train_dataloaders=train_loader,
                val_dataloaders=validation_loader,
            )

            self.checkpoint_path = checkpoint_callback.best_model_path

            if self.checkpoint_path:
                self._log(
                    f"💾 Best checkpoint: "
                    f"{Path(self.checkpoint_path).name}"
                )

            best_score = checkpoint_callback.best_model_score

            if best_score is not None:
                best_score = float(best_score.detach().cpu().item())
                self.training_history["best_val_loss"] = best_score

            self.training_history["epochs_completed"] = (
                lightning_trainer.current_epoch + 1
            )

            self.is_trained = True
            self._log("🏁 Real TFT training complete")

            return True

        except Exception as exc:
            self._log(f"❌ Real TFT training error: {exc}")
            traceback.print_exc()
            return False

    def save_model(self, filename):
        """
        Save a Lightning checkpoint plus dataset metadata.

        The .ckpt file is the actual model checkpoint. The metadata file
        preserves the TimeSeriesDataSet configuration required for inference.
        """
        if not self.is_trained or self.model is None:
            self._log("⚠️ No trained model available")
            return False

        try:
            output_dir = Path(MODEL_DIR)
            output_dir.mkdir(parents=True, exist_ok=True)

            output_path = output_dir / filename

            if output_path.suffix != ".ckpt":
                output_path = output_path.with_suffix(".ckpt")

            self.model.to("cpu")
            self.model.save_checkpoint(str(output_path))

            metadata_path = output_path.with_suffix(".pkl")

            metadata = {
                "model_type": (
                    "pytorch_forecasting.TemporalFusionTransformer"
                ),
                "checkpoint_path": str(output_path),
                "dataset_parameters": self.dataset_parameters,
                "feature_columns": (
                    self.training_dataset.reals
                    if self.training_dataset is not None
                    else []
                ),
                "training_history": self.training_history,
                "training_time": datetime.now().isoformat(),
                "lookback": self.training_dataset.max_encoder_length,
                "horizon": self.training_dataset.max_prediction_length,
            }

            with open(metadata_path, "wb") as file:
                pickle.dump(metadata, file)

            self._log(f"✅ TFT checkpoint saved: {output_path}")
            self._log(f"✅ Dataset metadata saved: {metadata_path}")

            return True

        except Exception as exc:
            self._log(f"❌ Save error: {exc}")
            traceback.print_exc()
            return False


class TFTTrainerGUI(CTk):
    def __init__(self):
        super().__init__()

        self.title(Config.APP_TITLE)
        self.geometry(Config.APP_GEOMETRY)
        self.resizable(False, False)

        self.gui_logger = GUILogger()
        self.gui_logger.enable_console_redirect()

        self.csv_folder = Config.DATASET_DIR
        self.model_folder = Config.MODEL_DIR
        self.available_symbols = []
        self.is_training = False
        self.stop_flag = False

        self.data_preparer = StreamingDataPreparer(self.gui_logger.log)
        self.trainer = StreamingTFTTrainer(self.gui_logger.log)

        self._create_ui()
        self.gui_logger.set_log_widget(self.log_text)
        self.after(500, self.scan_data_source)

        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _create_ui(self):
        main_frame = CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Title
        title_frame = CTkFrame(main_frame, corner_radius=10)
        title_frame.pack(fill="x", pady=(0, 10))

        CTkLabel(title_frame, text="🎯 TFT Model Trainer",
                font=("Ubuntu", 18, "bold")).pack(pady=10)
        CTkLabel(title_frame, text="Copyright Su Nie | BSD-C3 License | https://github.com/can87683",
                font=("Ubuntu", 16), text_color="yellow").pack(pady=(0, 10))

        # Usage Row
        self.usage_row = UsageRow(main_frame)

        # CSV Section
        self._create_csv_section(main_frame)

        # Model Folder Section
        self._create_model_folder_section(main_frame)

        # Parameters Section
        self._create_parameters_section(main_frame)

        # Features Section
        self._create_features_section(main_frame)

        # Controls Section
        self._create_controls_section(main_frame)

        # Status Section
        self._create_status_section(main_frame)

        # Log Section
        self._create_log_section(main_frame)

    def _create_csv_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_csv_btn = CTkButton(folder_frame, text="📁 CSV Folder",
                                        command=self.select_csv_folder, width=140, height=32)
        self.select_csv_btn.pack(side="left", padx=(0, 10))

        self.csv_path_var = tk.StringVar(value=str(self.csv_folder))
        csv_entry = CTkEntry(folder_frame, textvariable=self.csv_path_var, state="readonly", height=32)
        csv_entry.pack(side="left", fill="x", expand=True)

    def _create_model_folder_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_model_btn = CTkButton(folder_frame, text="📁 Model Folder",
                                          command=self.select_model_folder, width=140, height=32)
        self.select_model_btn.pack(side="left", padx=(0, 10))

        self.model_path_var = tk.StringVar(value=str(self.model_folder))
        model_entry = CTkEntry(folder_frame, textvariable=self.model_path_var, state="readonly", height=32)
        model_entry.pack(side="left", fill="x", expand=True)

        self.status_label = CTkLabel(frame, text="📊 Status: No folder selected", font=("Ubuntu", 12))
        self.status_label.pack(anchor="w", padx=10, pady=5)

    def _create_parameters_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        param_frame = CTkFrame(frame, fg_color="transparent")
        param_frame.pack(fill="x", padx=10, pady=5)

        self.lookback = tk.StringVar(value=str(Config.DEFAULT_LOOKBACK))
        self.horizon = tk.StringVar(value=str(Config.DEFAULT_HORIZON))
        self.epochs = tk.StringVar(value=str(Config.DEFAULT_EPOCHS))
        self.batch_size = tk.StringVar(value=str(Config.DEFAULT_BATCH_SIZE))

        row = CTkFrame(param_frame, fg_color="transparent")
        row.pack(fill="x", pady=2)

        row.grid_columnconfigure(0, weight=0)
        row.grid_columnconfigure(1, weight=1)
        row.grid_columnconfigure(2, weight=0)
        row.grid_columnconfigure(3, weight=1)
        row.grid_columnconfigure(4, weight=0)
        row.grid_columnconfigure(5, weight=1)
        row.grid_columnconfigure(6, weight=0)
        row.grid_columnconfigure(7, weight=1)

        CTkLabel(row, text="Lookback:", width=80).grid(row=0, column=0, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.lookback, width=80).grid(row=0, column=1, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Horizon:", width=80).grid(row=0, column=2, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.horizon, width=80).grid(row=0, column=3, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Epochs:", width=80).grid(row=0, column=4, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.epochs, width=80).grid(row=0, column=5, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Batch:", width=80).grid(row=0, column=6, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.batch_size, width=80).grid(row=0, column=7, sticky="w")

    def _create_features_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        feature_frame = CTkFrame(frame, fg_color="transparent")
        feature_frame.pack(fill="x", padx=10, pady=5)

        default_features = "time,open,high,low,close,volume"
        self.feature_cols_var = tk.StringVar(value=default_features)

        CTkLabel(feature_frame, text="Base Features (comma-separated):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))
        feature_entry = CTkEntry(feature_frame, textvariable=self.feature_cols_var, height=32)
        feature_entry.pack(fill="x", pady=(0, 5))

    def _create_controls_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        button_frame = CTkFrame(frame, fg_color="transparent")
        button_frame.pack(pady=10)

        self.train_btn = CTkButton(button_frame, text="🚀 Start Training",
                                   command=self.start_training, width=140, height=40,
                                   fg_color="#2e7d32", hover_color="#1b5e20",
                                   font=("Ubuntu", 13, "bold"))
        self.train_btn.pack(side="left", padx=5)

        self.stop_btn = CTkButton(button_frame, text="⏹️ Stop Training",
                                  command=self.stop_training, width=140, height=40,
                                  fg_color="#c62828", hover_color="#b71c1c",
                                  font=("Ubuntu", 13, "bold"), state="disabled")
        self.stop_btn.pack(side="left", padx=5)

    def _create_status_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        self.status_text = CTkTextbox(frame, height=80, font=("Ubuntu Mono", 11))
        self.status_text.pack(fill="x", padx=10, pady=5)
        self.status_text.insert("1.0", "Ready")
        self.status_text.configure(state="disabled")

    def _create_log_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="both", expand=True)

        self.log_text = CTkTextbox(frame, font=("Ubuntu Mono", 11))
        self.log_text.pack(fill="both", expand=True, padx=10, pady=5)

    def update_status(self, message):
        self.status_text.configure(state="normal")
        self.status_text.delete("1.0", "end")
        self.status_text.insert("1.0", message)
        self.status_text.configure(state="disabled")
        self.status_text.update_idletasks()

    def select_csv_folder(self):
        folder = filedialog.askdirectory(title="Select CSV Data Folder", initialdir=str(self.csv_folder))
        if folder:
            self.csv_path_var.set(folder)
            self.scan_data_source()

    def select_model_folder(self):
        folder = filedialog.askdirectory(title="Select Model Save Folder", initialdir=str(self.model_folder))
        if folder:
            self.model_path_var.set(folder)
            global MODEL_DIR
            MODEL_DIR = Path(folder)
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            self.gui_logger.log(f"💾 Model folder set to: {MODEL_DIR}")

    def scan_data_source(self):
        csv_folder = Path(self.csv_path_var.get())
        if not csv_folder.exists():
            self.gui_logger.log(f"❌ CSV folder not found: {csv_folder}", "error")
            self.status_label.configure(text="❌ Folder not found")
            self.train_btn.configure(state="disabled")
            return

        self.gui_logger.log(f"📁 Scanning CSV folder: {csv_folder}")
        symbols, timeframes = self.data_preparer.scan_folder(csv_folder)

        if not symbols:
            self.gui_logger.log("⚠️ No symbols found", "warning")
            self.status_label.configure(text="⚠️ No symbols found")
            self.train_btn.configure(state="disabled")
            return

        self.available_symbols = [s[0] for s in symbols]
        self.available_timeframes = timeframes

        self.status_label.configure(text=f"✅ Found {len(symbols)} symbols, {len(timeframes)} timeframes")
        self.gui_logger.log(f"✅ Loaded {len(symbols)} symbols", "success")
        self.train_btn.configure(state="normal")

    def start_training(self):
        if self.is_training:
            self.gui_logger.log("⏳ Training already in progress", "warning")
            return

        csv_folder = self.csv_path_var.get()
        if not Path(csv_folder).exists():
            self.gui_logger.log("❌ Invalid CSV folder", "error")
            return

        self.is_training = True
        self.stop_flag = False
        self.train_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        def training_task():
            try:
                self.gui_logger.log("=" * 60)
                self.gui_logger.log("🚀 Starting Streaming TFT Training")
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"📂 CSV Folder: {csv_folder}")
                self.gui_logger.log(f"💾 System RAM: {MemoryOptimizer.get_system_memory_available_gb():.1f} GB available")

                feature_input = self.feature_cols_var.get().strip()
                if feature_input:
                    feature_cols = [f.strip() for f in feature_input.split(',') if f.strip()]
                else:
                    feature_cols = Config.DEFAULT_FEATURES

                lookback = int(self.lookback.get())
                horizon = int(self.horizon.get())
                batch_size = int(self.batch_size.get())
                epochs = int(self.epochs.get())

                self.update_status("Creating streaming data pipeline...")

                self.update_status(
                    "Preparing PyTorch Forecasting TimeSeriesDataSet..."
                )

                success = self.trainer.train_streaming(
                    data_stream=None,
                    total_samples=0,
                    epochs=epochs,
                    batch_size=batch_size,
                    lookback=lookback,
                    horizon=horizon,
                    csv_folder=csv_folder,
                    feature_cols=feature_cols,
                    data_preparer=self.data_preparer,
                )

                if success and not self.stop_flag:
                    self.update_status("Saving model...")
                    filename = "ai_predict_tft_all.ckpt"
                    if self.trainer.save_model(filename):
                        self.gui_logger.log(f"✅ Model saved: {filename}", "success")
                        self.update_status(f"✅ Training complete! Model: {filename}")
                    else:
                        self.update_status("❌ Failed to save model")
                elif self.stop_flag:
                    self.gui_logger.log("⏹️ Training stopped by user", "warning")
                    self.update_status("Training stopped")
                else:
                    self.update_status("❌ Training failed")

            except Exception as e:
                self.gui_logger.log(f"❌ Training error: {e}", "error")
                traceback.print_exc()
                self.update_status(f"Error: {e}")
            finally:
                self.is_training = False
                self.train_btn.configure(state="normal")
                self.stop_btn.configure(state="disabled")

        threading.Thread(target=training_task, daemon=True).start()

    def stop_training(self):
        self.stop_flag = True
        self.gui_logger.log("⏹️ Stopping training...", "warning")

    def _on_closing(self):
        self.gui_logger.disable_console_redirect()
        if self.is_training:
            result = messagebox.askyesno("Training in Progress",
                "Training is currently running.\n\nDo you want to stop training and quit?",
                icon='warning')
            if result:
                self.stop_flag = True
                self.after(100, self.destroy)
        else:
            result = messagebox.askyesno("Quit", "Do you want to quit AI Predict Train?")
            if result:
                self.destroy()

def main():
    app = TFTTrainerGUI()
    app.mainloop()

if __name__ == "__main__":
    main()