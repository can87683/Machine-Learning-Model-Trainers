#!/usr/bin/env python3
# ai_predict_train_xgboost_ctk.py
# Copyright Su Nie | BSD-C-3 License | https://github.com/can87683

import setproctitle
setproctitle.setproctitle("ai_predict_train_xgboost_ctk")

import customtkinter as ctk
from customtkinter import CTk, CTkFrame, CTkLabel, CTkButton, CTkEntry, CTkTextbox
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import subprocess
from pathlib import Path
import numpy as np
import pandas as pd
import pickle
import json
import gc
import psutil
from datetime import datetime
import traceback
import sys
import os
import time
import warnings

import xgboost as xgb

# Suppress FutureWarnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)


# ===== Configuration Class =====
class Config:
    """Central configuration for all settings"""

    # Paths
    HOME = Path.home()
    MODEL_DIR = HOME / "ai_models"
    DATASET_DIR = HOME / "mt5_data"

    # Data settings
    MAX_ROWS_PER_SYMBOL = 5000
    MAX_DATASET_ROWS = 100000
    DEFAULT_FEATURES = ['time', 'open', 'high', 'low', 'close', 'volume']

    # Model settings (XGBoost)
    DEFAULT_HORIZON = 10
    DEFAULT_ITERATIONS = 1000
    DEFAULT_LEARNING_RATE = 0.05
    DEFAULT_MAX_DEPTH = 6
    DEFAULT_L2_REG = 1.0          # XGBoost reg_lambda
    DEFAULT_SUBSAMPLE = 0.8
    DEFAULT_COLSAMPLE = 0.8

    # Training settings
    EARLY_STOPPING_ROUNDS = 50
    VALIDATION_FRACTION = 0.15  # last X% of each symbol's series, chronologically

    # Memory settings
    MEMORY_WARNING_THRESHOLD_GB = 0.5

    # Timeframes -> one independent model is trained per timeframe
    TIMEFRAMES = ['M5', 'M15', 'H1', 'H4', 'D1', 'W1']

    # Output naming
    MODEL_PREFIX = "ai_predict_xgboost"
    MODEL_EXT = ".json"         # XGBoost JSON format (portable)
    METADATA_EXT = ".pkl"

    # UI settings
    APP_TITLE = "🚀 XGBoost Model Trainer"
    APP_GEOMETRY = "640x1200"
    THEME = "dark"
    COLOR_THEME = "dark-blue"

    @classmethod
    def ensure_directories(cls):
        cls.MODEL_DIR.mkdir(parents=True, exist_ok=True)
        cls.DATASET_DIR.mkdir(parents=True, exist_ok=True)


Config.ensure_directories()

# ===== CTK Theme Settings =====
ctk.set_appearance_mode(Config.THEME)
ctk.set_default_color_theme(Config.COLOR_THEME)

# ===== Constants =====
HOME = Config.HOME
MODEL_DIR = Config.MODEL_DIR
DATASET_DIR = Config.DATASET_DIR


# ===== GPU Manager (XGBoost device selection with safe fallback) =====
class GPUManager:
    """
    Detects an NVIDIA GPU via nvidia-smi for informational logging, then
    lets the trainer actually attempt XGBoost's device='cuda' (modern
    XGBoost 2.x API: tree_method='hist' + device='cuda'/'cpu', replacing the
    older 'gpu_hist' tree method). If the installed xgboost build/driver
    combination can't actually train on the GPU, the trainer catches that
    at fit time and falls back to device='cpu' automatically, so a GPU is
    used whenever one is genuinely usable.
    """

    def __init__(self, verbose=True):
        self.verbose = verbose
        self.gpu_available = False
        self.gpu_name = None
        self._detect_gpu()

    def _log(self, message):
        if self.verbose:
            print(f"[GPUManager] {message}")

    def _detect_gpu(self):
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                self.gpu_available = True
                self.gpu_name = result.stdout.strip().splitlines()[0]
                self._log(f"✅ GPU detected: {self.gpu_name}")
            else:
                self._log("ℹ️ No GPU detected, using CPU")
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
            self.gpu_available = False
            self._log("ℹ️ No GPU detected, using CPU")

    def preferred_devices(self):
        """Ordered list of XGBoost `device` values to attempt, most-preferred first."""
        if self.gpu_available:
            return ["cuda", "cpu"]
        return ["cpu"]


# ===== Usage Row Class =====
class UsageRow:
    """System usage monitoring row for the GUI"""

    def __init__(self, parent):
        self.parent = parent
        self.usage_frame = None
        self.usage_label = None
        self._create_usage_row()

    def _create_usage_row(self):
        self.usage_frame = CTkFrame(self.parent, height=40, corner_radius=5)
        self.usage_frame.pack(fill="x", pady=(0, 10))

        self.usage_label = CTkLabel(
            self.usage_frame,
            text="Loading system usage...",
            font=("Ubuntu Mono", 20),
            text_color="Lime"
        )
        self.usage_label.pack(expand=True, fill="x", padx=10, pady=5)

        self._update_usage()

    def _update_usage(self):
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            dram = psutil.virtual_memory().percent

            gpu_percent = 0
            vram_percent = 0
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_percent = gpu.load * 100
                    vram_percent = gpu.memoryUtil * 100
            except (ImportError, Exception):
                pass

            self.usage_label.configure(
                text=f"CPU: {cpu:.1f}%  DRAM: {dram:.1f}%  GPU: {gpu_percent:.1f}%  VRAM: {vram_percent:.1f}%"
            )
        except Exception:
            self.usage_label.configure(text="⚠️ System monitoring unavailable")

        self.usage_label.after(2000, self._update_usage)


# ===== Console Logger =====
class ConsoleLogger:
    def __init__(self, gui_logger, original_stream):
        self.gui_logger = gui_logger
        self.original_stream = original_stream

    def write(self, message):
        if message and message.strip():
            self.original_stream.write(message)
            self.original_stream.flush()
            if self.gui_logger:
                self.gui_logger.log(message.strip(), "console")

    def flush(self):
        self.original_stream.flush()


# ===== Memory Optimizer =====
class MemoryOptimizer:
    @staticmethod
    def get_system_memory_gb():
        return psutil.virtual_memory().total / 1e9

    @staticmethod
    def get_system_memory_available_gb():
        return psutil.virtual_memory().available / 1e9

    @staticmethod
    def clear_cache():
        gc.collect()

    @staticmethod
    def monitor_memory(threshold_gb=0.5):
        return MemoryOptimizer.get_system_memory_available_gb() < threshold_gb


# ===== Feature Engineer =====
class FeatureEngineer:
    """Extract time-based and technical features"""

    @staticmethod
    def add_time_features(df):
        if 'time' not in df.columns:
            return df

        if not pd.api.types.is_datetime64_any_dtype(df['time']):
            df['time'] = pd.to_datetime(df['time'])

        df['hour'] = df['time'].dt.hour
        df['day_of_week'] = df['time'].dt.dayofweek
        df['day_of_month'] = df['time'].dt.day
        df['month'] = df['time'].dt.month
        df['quarter'] = df['time'].dt.quarter
        df['year'] = df['time'].dt.year

        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)

        return df

    @staticmethod
    def add_technical_features(df):
        if all(c in df.columns for c in ['high', 'low', 'close']):
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_high_ratio'] = df['close'] / df['high']
            df['close_low_ratio'] = df['close'] / df['low']

        if 'close' in df.columns:
            df['returns_1'] = df['close'].pct_change()
            df['returns_5'] = df['close'].pct_change(periods=5)
            df['returns_10'] = df['close'].pct_change(periods=10)

        if 'volume' in df.columns:
            df['volume_ma_5'] = df['volume'].rolling(5).mean()
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(5).mean()

        return df


class GUILogger:
    def __init__(self):
        self.messages = []
        self.log_widget = None
        self.ready = False
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr

    def set_log_widget(self, widget):
        self.log_widget = widget
        self.ready = True
        self.log_widget.configure(font=("Ubuntu Mono", 11))
        for msg, level in self.messages:
            self._write_to_widget(msg, level)
        self.messages.clear()

    def _write_to_widget(self, message, level):
        if self.log_widget:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {message}\n"
            try:
                self.log_widget.insert("end", log_entry)
                self.log_widget.see("end")
                self.log_widget.update_idletasks()
            except Exception:
                print(log_entry, flush=True)

    def log(self, message, level="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_entry = f"[{timestamp}] [{level.upper()}] {message}"
        try:
            self._original_stdout.write(console_entry + "\n")
            self._original_stdout.flush()
        except Exception:
            print(console_entry, flush=True)
        if self.ready and self.log_widget:
            self._write_to_widget(message, level)
        else:
            self.messages.append((message, level))

    def enable_console_redirect(self):
        sys.stdout = ConsoleLogger(self, self._original_stdout)
        sys.stderr = ConsoleLogger(self, self._original_stderr)

    def disable_console_redirect(self):
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr


class StreamingDataPreparer:
    """Builds an XGBoost-ready tabular dataframe, one timeframe at a time."""

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print
        self.feature_cols = []
        self.categorical_features = ["group_id"]
        self.target_column = "target"

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def load_csv_data(self, symbol, timeframe, csv_folder):
        csv_file = Path(csv_folder) / symbol / f"{symbol}_{timeframe}.csv"

        if not csv_file.exists():
            return None

        try:
            df = pd.read_csv(csv_file)

            if "time" not in df.columns:
                self._log(f"⚠️ Missing time column: {csv_file}")
                return None

            if pd.api.types.is_numeric_dtype(df["time"]):
                df["time"] = pd.to_datetime(df["time"], unit="s")
            else:
                df["time"] = pd.to_datetime(df["time"])

            df = (
                df.sort_values("time")
                .drop_duplicates("time")
                .reset_index(drop=True)
            )

            return df

        except Exception as exc:
            self._log(f"❌ Error loading {csv_file}: {exc}")
            return None

    def scan_folder(self, csv_folder):
        csv_folder = Path(csv_folder)

        if not csv_folder.exists():
            return [], []

        symbols = []
        all_timeframes = set()

        for symbol_dir in sorted(csv_folder.iterdir()):
            if not symbol_dir.is_dir():
                continue

            symbol = symbol_dir.name
            found_timeframes = []

            for timeframe in Config.TIMEFRAMES:
                csv_file = symbol_dir / f"{symbol}_{timeframe}.csv"

                if csv_file.exists():
                    found_timeframes.append(timeframe)
                    all_timeframes.add(timeframe)

            if found_timeframes:
                symbols.append((symbol, found_timeframes))
                self._log(f"   ✓ {symbol}: {', '.join(found_timeframes)}")

        return symbols, sorted(all_timeframes)

    def _prepare_single_series(self, df, symbol, horizon, requested_features):
        if df is None or len(df) < 100:
            return None

        df = df.copy()

        if len(df) > Config.MAX_ROWS_PER_SYMBOL:
            df = df.iloc[-Config.MAX_ROWS_PER_SYMBOL:].copy()

        df = FeatureEngineer.add_time_features(df)
        df = FeatureEngineer.add_technical_features(df)

        requested_features = [c for c in requested_features if c != "time"]

        engineered_features = [
            "hour_sin", "hour_cos", "day_sin", "day_cos",
            "month_sin", "month_cos",
            "high_low_ratio", "close_high_ratio", "close_low_ratio",
            "returns_1", "returns_5", "returns_10", "volume_ratio",
        ]

        candidate_features = list(dict.fromkeys(requested_features + engineered_features))
        available_features = [c for c in candidate_features if c in df.columns]

        required_columns = ["open", "high", "low", "close", "volume"]
        for column in required_columns:
            if column in df.columns and column not in available_features:
                available_features.append(column)

        if "close" not in df.columns:
            self._log(f"⚠️ Skipping {symbol}: close column unavailable")
            return None

        if not available_features:
            self._log(f"⚠️ Skipping {symbol}: no usable features")
            return None

        df[available_features] = (
            df[available_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
        )

        df[self.target_column] = df["close"].shift(-horizon)
        df = df.dropna(subset=[self.target_column]).copy()

        if len(df) < 50:
            return None

        # Keep group_id as a string; it's cast to a native pandas 'category'
        # dtype right before fitting so XGBoost's built-in categorical
        # support (enable_categorical=True) can consume it directly.
        df["group_id"] = str(symbol)
        df["time_idx"] = np.arange(len(df), dtype=np.int64)

        keep_columns = ["time", "time_idx", "group_id", self.target_column] + available_features
        return df[keep_columns], available_features

    def build_dataframe_for_timeframe(self, csv_folder, feature_cols, horizon, timeframe):
        """
        Build one combined dataframe for a SINGLE timeframe, stacking every
        symbol that has that timeframe available. 'group_id' (the symbol)
        stays a string and is fed to XGBoost as a native categorical column
        so one model can generalize across instruments for that timeframe.
        """
        csv_folder = Path(csv_folder)
        symbols, _ = self.scan_folder(csv_folder)

        symbols_with_tf = [s for s, tfs in symbols if timeframe in tfs]

        if not symbols_with_tf:
            raise ValueError(f"No symbols found with timeframe {timeframe} in {csv_folder}")

        frames = []
        all_features = []

        for symbol in symbols_with_tf:
            df = self.load_csv_data(symbol, timeframe, csv_folder)
            prepared = self._prepare_single_series(df, symbol, horizon, feature_cols)

            if prepared is None:
                continue

            prepared_df, available_features = prepared
            frames.append(prepared_df)
            all_features.extend(available_features)

            self._log(f"   📊 {symbol}_{timeframe}: {len(prepared_df)} rows")

        if not frames:
            raise ValueError(f"No usable series produced for timeframe {timeframe}")

        all_features = list(dict.fromkeys(all_features))
        result = pd.concat(frames, ignore_index=True, sort=False)

        for column in all_features:
            if column not in result.columns:
                result[column] = 0.0

        result[all_features] = (
            result[all_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
            .astype(np.float32)
        )

        result[self.target_column] = (
            result[self.target_column]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .astype(np.float32)
        )

        result["group_id"] = result["group_id"].astype(str)

        result = result.sort_values(["group_id", "time_idx"]).reset_index(drop=True)

        self.feature_cols = all_features
        self._log(f"✅ [{timeframe}] Prepared {len(result):,} rows, {result['group_id'].nunique()} symbols")
        self._log(f"✅ [{timeframe}] Numeric features: {len(self.feature_cols)}")

        return result


class StreamingXGBoostTrainer:
    """
    Trains one independent XGBRegressor per timeframe.
    Each call to train_single_timeframe() produces one model.
    """

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print

        self.gpu_manager = GPUManager(verbose=False)

        self.model = None
        self.is_trained = False
        self.stop_flag = False
        self.device_used = "cpu"

        self.iterations = Config.DEFAULT_ITERATIONS
        self.learning_rate = Config.DEFAULT_LEARNING_RATE
        self.max_depth = Config.DEFAULT_MAX_DEPTH
        self.reg_lambda = Config.DEFAULT_L2_REG
        self.subsample = Config.DEFAULT_SUBSAMPLE
        self.colsample_bytree = Config.DEFAULT_COLSAMPLE

        self.training_history = {}

        preferred = " -> ".join(self.gpu_manager.preferred_devices())
        self._log(f"🚀 XGBoost trainer initialized. Device attempt order: {preferred.upper()}")

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def stop_training(self):
        self.stop_flag = True
        self._log("⏹️ Training stop requested")

    def _chronological_split(self, data):
        """Reserve the last VALIDATION_FRACTION of each symbol's rows for validation."""
        train_parts, val_parts = [], []

        for _, group in data.groupby("group_id"):
            group = group.sort_values("time_idx")
            n_val = max(1, int(len(group) * Config.VALIDATION_FRACTION))
            train_parts.append(group.iloc[:-n_val])
            val_parts.append(group.iloc[-n_val:])

        train_df = pd.concat(train_parts, ignore_index=True)
        val_df = pd.concat(val_parts, ignore_index=True)
        return train_df, val_df

    def _build_model(self, device, iterations, learning_rate, max_depth):
        """Construct a fresh XGBRegressor targeting a specific device.

        tree_method='hist' is required (on both CPU and GPU) for XGBoost's
        native categorical support (enable_categorical=True) to work; the
        modern `device` param ('cuda' / 'cpu') replaces the older
        tree_method='gpu_hist' from XGBoost < 2.0.
        """
        return xgb.XGBRegressor(
            n_estimators=iterations,
            learning_rate=learning_rate,
            max_depth=max_depth,
            reg_lambda=self.reg_lambda,
            subsample=self.subsample,
            colsample_bytree=self.colsample_bytree,
            objective="reg:squarederror",
            eval_metric="rmse",
            early_stopping_rounds=Config.EARLY_STOPPING_ROUNDS,
            tree_method="hist",
            device=device,
            enable_categorical=True,
            random_state=42,
            n_jobs=-1,
            verbosity=0,
        )

    def train_single_timeframe(
        self,
        data,
        feature_cols,
        timeframe,
        iterations=1000,
        learning_rate=0.05,
        max_depth=6,
        **kwargs,
    ):
        """Train one XGBRegressor for a single timeframe's dataframe.

        Tries each device in GPUManager.preferred_devices() in order
        (cuda -> cpu) and falls back automatically if the installed
        xgboost build/driver combination can't actually train on that
        device, so a GPU is used whenever one is genuinely usable.
        """
        try:
            self.stop_flag = False

            if len(data) == 0:
                raise ValueError("Prepared dataframe is empty")

            train_df, val_df = self._chronological_split(data)

            if len(train_df) == 0 or len(val_df) == 0:
                raise ValueError("Train/validation split produced an empty set")

            x_columns = feature_cols + ["group_id"]

            X_train = train_df[x_columns].copy()
            y_train = train_df["target"]
            X_val = val_df[x_columns].copy()
            y_val = val_df["target"]

            # Native XGBoost categorical handling for the symbol id
            X_train["group_id"] = X_train["group_id"].astype("category")
            X_val["group_id"] = X_val["group_id"].astype("category")

            self._log(f"📊 [{timeframe}] Training rows: {len(train_df):,}")
            self._log(f"📊 [{timeframe}] Validation rows: {len(val_df):,}")

            last_error = None
            fitted_model = None
            used_device = None

            for device in self.gpu_manager.preferred_devices():
                if self.stop_flag:
                    break

                model = self._build_model(device, iterations, learning_rate, max_depth)

                self._log(f"🚀 [{timeframe}] Attempting training on device='{device}'...")

                try:
                    fitted_model = model.fit(
                        X_train, y_train,
                        eval_set=[(X_val, y_val)],
                        verbose=False,
                    )
                    used_device = device
                    break
                except Exception as exc:
                    last_error = exc
                    self._log(
                        f"⚠️ [{timeframe}] device='{device}' failed "
                        f"({exc}); falling back..."
                    )
                    continue

            if fitted_model is None:
                raise last_error or RuntimeError("No device succeeded in training")

            self.model = fitted_model
            self.device_used = used_device
            self._log(f"✅ [{timeframe}] Trained using device='{used_device}'")

            best_iteration = self.model.best_iteration if hasattr(self.model, 'best_iteration') else iterations
            best_score = self.model.best_score if hasattr(self.model, 'best_score') else None

            self.training_history = {
                "timeframe": timeframe,
                "device_used": used_device,
                "best_iteration": best_iteration,
                "best_score": best_score,
                "train_rows": len(train_df),
                "val_rows": len(val_df),
            }

            self.is_trained = True

            self._log(
                f"🏁 [{timeframe}] Training complete "
                f"(device={used_device}, best_iter={best_iteration}, val_rmse={best_score})"
            )

            return True

        except Exception as exc:
            self._log(f"❌ [{timeframe}] Training error: {exc}")
            traceback.print_exc()
            return False

    def save_model(self, model_dir, filename_stem, feature_cols, horizon, timeframe):
        """Save the XGBoost model (.json) plus a metadata sidecar (.pkl)."""
        if not self.is_trained or self.model is None:
            self._log("⚠️ No trained model available")
            return False

        try:
            output_dir = Path(model_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            model_path = output_dir / f"{filename_stem}{Config.MODEL_EXT}"
            metadata_path = output_dir / f"{filename_stem}{Config.METADATA_EXT}"

            self.model.save_model(str(model_path))

            metadata = {
                "model_type": "xgboost.XGBRegressor",
                "timeframe": timeframe,
                "model_path": str(model_path),
                "feature_columns": feature_cols,
                "categorical_features": ["group_id"],
                "device_used": self.device_used,
                "horizon": horizon,
                "training_history": self.training_history,
                "training_time": datetime.now().isoformat(),
            }

            with open(metadata_path, "wb") as file:
                pickle.dump(metadata, file)

            self._log(f"✅ XGBoost model saved: {model_path}")
            self._log(f"✅ Metadata saved: {metadata_path}")

            return True

        except Exception as exc:
            self._log(f"❌ Save error: {exc}")
            traceback.print_exc()
            return False


class XGBoostTrainerGUI(CTk):
    def __init__(self):
        super().__init__()

        self.title(Config.APP_TITLE)
        self.geometry(Config.APP_GEOMETRY)
        self.resizable(False, False)

        self.gui_logger = GUILogger()
        self.gui_logger.enable_console_redirect()

        self.csv_folder = Config.DATASET_DIR
        self.model_folder = Config.MODEL_DIR
        self.available_symbols = []
        self.available_timeframes = []
        self.is_training = False
        self.stop_flag = False

        self.data_preparer = StreamingDataPreparer(self.gui_logger.log)
        self.trainer = StreamingXGBoostTrainer(self.gui_logger.log)

        self._create_ui()
        self.gui_logger.set_log_widget(self.log_text)
        self.after(500, self.scan_data_source)

        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _create_ui(self):
        main_frame = CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        title_frame = CTkFrame(main_frame, corner_radius=10)
        title_frame.pack(fill="x", pady=(0, 10))

        CTkLabel(title_frame, text="🎯 XGBoost Model Trainer (per timeframe)",
                 font=("Ubuntu", 18, "bold")).pack(pady=10)
        CTkLabel(title_frame, text="Copyright Su Nie | BSD-C-3 License | https://github.com/can87683",
                 font=("Ubuntu", 16), text_color="yellow").pack(pady=(0, 10))

        self.usage_row = UsageRow(main_frame)

        self._create_csv_section(main_frame)
        self._create_model_folder_section(main_frame)
        self._create_parameters_section(main_frame)
        self._create_features_section(main_frame)
        self._create_timeframes_section(main_frame)
        self._create_controls_section(main_frame)
        self._create_status_section(main_frame)
        self._create_log_section(main_frame)

    def _create_csv_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_csv_btn = CTkButton(folder_frame, text="📁 CSV Folder",
                                         command=self.select_csv_folder, width=140, height=32)
        self.select_csv_btn.pack(side="left", padx=(0, 10))

        self.csv_path_var = tk.StringVar(value=str(self.csv_folder))
        csv_entry = CTkEntry(folder_frame, textvariable=self.csv_path_var, state="readonly", height=32)
        csv_entry.pack(side="left", fill="x", expand=True)

    def _create_model_folder_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_model_btn = CTkButton(folder_frame, text="📁 Model Folder",
                                           command=self.select_model_folder, width=140, height=32)
        self.select_model_btn.pack(side="left", padx=(0, 10))

        self.model_path_var = tk.StringVar(value=str(self.model_folder))
        model_entry = CTkEntry(folder_frame, textvariable=self.model_path_var, state="readonly", height=32)
        model_entry.pack(side="left", fill="x", expand=True)

        self.status_label = CTkLabel(frame, text="📊 Status: No folder selected", font=("Ubuntu", 12))
        self.status_label.pack(anchor="w", padx=10, pady=5)

    def _create_parameters_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        param_frame = CTkFrame(frame, fg_color="transparent")
        param_frame.pack(fill="x", padx=10, pady=5)

        self.horizon = tk.StringVar(value=str(Config.DEFAULT_HORIZON))
        self.iterations = tk.StringVar(value=str(Config.DEFAULT_ITERATIONS))
        self.learning_rate = tk.StringVar(value=str(Config.DEFAULT_LEARNING_RATE))
        self.max_depth = tk.StringVar(value=str(Config.DEFAULT_MAX_DEPTH))

        row = CTkFrame(param_frame, fg_color="transparent")
        row.pack(fill="x", pady=2)

        for col in range(8):
            row.grid_columnconfigure(col, weight=1 if col % 2 else 0)

        CTkLabel(row, text="Horizon:", width=90).grid(row=0, column=0, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.horizon, width=80).grid(row=0, column=1, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Iterations:", width=90).grid(row=0, column=2, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.iterations, width=80).grid(row=0, column=3, padx=(0, 15), sticky="w")

        CTkLabel(row, text="LR:", width=90).grid(row=0, column=4, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.learning_rate, width=80).grid(row=0, column=5, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Depth:", width=90).grid(row=0, column=6, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.max_depth, width=80).grid(row=0, column=7, sticky="w")

    def _create_features_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        feature_frame = CTkFrame(frame, fg_color="transparent")
        feature_frame.pack(fill="x", padx=10, pady=5)

        default_features = "time,open,high,low,close,volume"
        self.feature_cols_var = tk.StringVar(value=default_features)

        CTkLabel(feature_frame, text="Base Features (comma-separated):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))
        feature_entry = CTkEntry(feature_frame, textvariable=self.feature_cols_var, height=32)
        feature_entry.pack(fill="x", pady=(0, 5))

    def _create_timeframes_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        tf_frame = CTkFrame(frame, fg_color="transparent")
        tf_frame.pack(fill="x", padx=10, pady=5)

        CTkLabel(tf_frame, text="Timeframes (one model each):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))

        self.tf_vars = {}
        checkboxes_frame = CTkFrame(tf_frame, fg_color="transparent")
        checkboxes_frame.pack(fill="x")

        for i, tf in enumerate(Config.TIMEFRAMES):
            var = tk.BooleanVar(value=True)
            self.tf_vars[tf] = var
            ctk.CTkCheckBox(checkboxes_frame, text=tf, variable=var, width=90).grid(
                row=0, column=i, padx=5, sticky="w"
            )

    def _create_controls_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        button_frame = CTkFrame(frame, fg_color="transparent")
        button_frame.pack(pady=10)

        self.train_btn = CTkButton(button_frame, text="🚀 Start Training",
                                    command=self.start_training, width=140, height=40,
                                    fg_color="#2e7d32", hover_color="#1b5e20",
                                    font=("Ubuntu", 13, "bold"))
        self.train_btn.pack(side="left", padx=5)

        self.stop_btn = CTkButton(button_frame, text="⏹️ Stop Training",
                                   command=self.stop_training, width=140, height=40,
                                   fg_color="#c62828", hover_color="#b71c1c",
                                   font=("Ubuntu", 13, "bold"), state="disabled")
        self.stop_btn.pack(side="left", padx=5)

    def _create_status_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        self.status_text = CTkTextbox(frame, height=80, font=("Ubuntu Mono", 11))
        self.status_text.pack(fill="x", padx=10, pady=5)
        self.status_text.insert("1.0", "Ready")
        self.status_text.configure(state="disabled")

    def _create_log_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="both", expand=True)

        self.log_text = CTkTextbox(frame, font=("Ubuntu Mono", 11))
        self.log_text.pack(fill="both", expand=True, padx=10, pady=5)

    def update_status(self, message):
        self.status_text.configure(state="normal")
        self.status_text.delete("1.0", "end")
        self.status_text.insert("1.0", message)
        self.status_text.configure(state="disabled")
        self.status_text.update_idletasks()

    def select_csv_folder(self):
        folder = filedialog.askdirectory(title="Select CSV Data Folder", initialdir=str(self.csv_folder))
        if folder:
            self.csv_path_var.set(folder)
            self.scan_data_source()

    def select_model_folder(self):
        folder = filedialog.askdirectory(title="Select Model Save Folder", initialdir=str(self.model_folder))
        if folder:
            self.model_path_var.set(folder)
            global MODEL_DIR
            MODEL_DIR = Path(folder)
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            self.gui_logger.log(f"💾 Model folder set to: {MODEL_DIR}")

    def scan_data_source(self):
        csv_folder = Path(self.csv_path_var.get())
        if not csv_folder.exists():
            self.gui_logger.log(f"❌ CSV folder not found: {csv_folder}", "error")
            self.status_label.configure(text="❌ Folder not found")
            self.train_btn.configure(state="disabled")
            return

        self.gui_logger.log(f"📁 Scanning CSV folder: {csv_folder}")
        symbols, timeframes = self.data_preparer.scan_folder(csv_folder)

        if not symbols:
            self.gui_logger.log("⚠️ No symbols found", "warning")
            self.status_label.configure(text="⚠️ No symbols found")
            self.train_btn.configure(state="disabled")
            return

        self.available_symbols = [s[0] for s in symbols]
        self.available_timeframes = timeframes

        self.status_label.configure(text=f"✅ Found {len(symbols)} symbols, {len(timeframes)} timeframes")
        self.gui_logger.log(f"✅ Loaded {len(symbols)} symbols", "success")
        self.train_btn.configure(state="normal")

    def start_training(self):
        if self.is_training:
            self.gui_logger.log("⏳ Training already in progress", "warning")
            return

        csv_folder = self.csv_path_var.get()
        if not Path(csv_folder).exists():
            self.gui_logger.log("❌ Invalid CSV folder", "error")
            return

        selected_timeframes = [tf for tf, var in self.tf_vars.items() if var.get()]
        if not selected_timeframes:
            self.gui_logger.log("❌ Select at least one timeframe", "error")
            return

        self.is_training = True
        self.stop_flag = False
        self.train_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        def training_task():
            try:
                self.gui_logger.log("=" * 60)
                self.gui_logger.log("🚀 Starting Per-Timeframe XGBoost Training")
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"📂 CSV Folder: {csv_folder}")
                self.gui_logger.log(
                    f"💾 System RAM: {MemoryOptimizer.get_system_memory_available_gb():.1f} GB available"
                )

                feature_input = self.feature_cols_var.get().strip()
                if feature_input:
                    feature_cols = [f.strip() for f in feature_input.split(',') if f.strip()]
                else:
                    feature_cols = Config.DEFAULT_FEATURES

                horizon = int(self.horizon.get())
                iterations = int(self.iterations.get())
                learning_rate = float(self.learning_rate.get())
                max_depth = int(self.max_depth.get())

                model_folder = self.model_path_var.get()

                results = {}

                for timeframe in selected_timeframes:
                    if self.stop_flag:
                        self.gui_logger.log("⏹️ Training stopped by user", "warning")
                        break

                    self.gui_logger.log("-" * 60)
                    self.gui_logger.log(f"▶️ Timeframe: {timeframe}")
                    self.update_status(f"[{timeframe}] Building dataset...")

                    try:
                        data = self.data_preparer.build_dataframe_for_timeframe(
                            csv_folder=csv_folder,
                            feature_cols=feature_cols,
                            horizon=horizon,
                            timeframe=timeframe,
                        )
                    except ValueError as exc:
                        self.gui_logger.log(f"⚠️ [{timeframe}] Skipped: {exc}", "warning")
                        results[timeframe] = "skipped (no data)"
                        continue

                    feature_columns = self.data_preparer.feature_cols

                    self.update_status(f"[{timeframe}] Training XGBoost model...")

                    success = self.trainer.train_single_timeframe(
                        data=data,
                        feature_cols=feature_columns,
                        timeframe=timeframe,
                        iterations=iterations,
                        learning_rate=learning_rate,
                        max_depth=max_depth,
                    )

                    if success and not self.trainer.stop_flag:
                        filename_stem = f"{Config.MODEL_PREFIX}_{timeframe}"
                        if self.trainer.save_model(
                            model_dir=model_folder,
                            filename_stem=filename_stem,
                            feature_cols=feature_columns,
                            horizon=horizon,
                            timeframe=timeframe,
                        ):
                            self.gui_logger.log(f"✅ [{timeframe}] Model saved: {filename_stem}{Config.MODEL_EXT}", "success")
                            results[timeframe] = f"trained ({self.trainer.device_used})"
                        else:
                            results[timeframe] = "failed to save"
                    elif self.trainer.stop_flag:
                        results[timeframe] = "stopped"
                        self.stop_flag = True
                    else:
                        results[timeframe] = "training failed"

                summary = ", ".join(f"{tf}: {status}" for tf, status in results.items())
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"🏁 Summary: {summary}")
                self.update_status(f"Done. {summary}")

            except Exception as e:
                self.gui_logger.log(f"❌ Training error: {e}", "error")
                traceback.print_exc()
                self.update_status(f"Error: {e}")
            finally:
                self.is_training = False
                self.train_btn.configure(state="normal")
                self.stop_btn.configure(state="disabled")

        threading.Thread(target=training_task, daemon=True).start()

    def stop_training(self):
        self.stop_flag = True
        self.trainer.stop_training()
        self.gui_logger.log("⏹️ Stopping training...", "warning")

    def _on_closing(self):
        self.gui_logger.disable_console_redirect()
        if self.is_training:
            result = messagebox.askyesno(
                "Training in Progress",
                "Training is currently running.\n\nDo you want to stop training and quit?",
                icon='warning',
            )
            if result:
                self.stop_flag = True
                self.trainer.stop_training()
                self.after(100, self.destroy)
        else:
            result = messagebox.askyesno("Quit", "Do you want to quit AI Predict Train (XGBoost)?")
            if result:
                self.destroy()


def main():
    app = XGBoostTrainerGUI()
    app.mainloop()


if __name__ == "__main__":
    main()