#!/usr/bin/env python3
# ai_predict_train_randomforest_ctk.py - CTK RandomForest Trainer (Per Symbol/Timeframe)
# Copyright Su Nie | BSD-C-3 License | https://github.com/can87683

import setproctitle
setproctitle.setproctitle("ai_predict_train_randomforest_ctk")

import customtkinter as ctk
from customtkinter import CTk, CTkFrame, CTkLabel, CTkButton, CTkEntry, CTkTextbox
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import subprocess
from pathlib import Path
import numpy as np
import pandas as pd
import pickle
import joblib
import gc
import psutil
from datetime import datetime
import traceback
import sys
import warnings

from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error

# Suppress FutureWarnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)


# ===== Configuration Class =====
class Config:
    """Central configuration for all settings"""

    # Paths
    HOME = Path.home()
    MODEL_DIR = HOME / "ai_models"
    DATASET_DIR = HOME / "mt5_data"

    # Data settings
    MAX_ROWS_PER_SYMBOL = 5000
    MAX_DATASET_ROWS = 100000
    DEFAULT_FEATURES = ['time', 'open', 'high', 'low', 'close', 'volume']

    # Model settings (Random Forest)
    DEFAULT_HORIZON = 10
    DEFAULT_N_ESTIMATORS = 300
    DEFAULT_MAX_DEPTH = 12          # 0 => None (unlimited)
    DEFAULT_MIN_SAMPLES_LEAF = 5

    # Training settings
    VALIDATION_FRACTION = 0.15  # last X% of each symbol's series, chronologically

    # Memory settings
    MEMORY_WARNING_THRESHOLD_GB = 0.5

    # Timeframes -> one independent model is trained per timeframe
    TIMEFRAMES = ['M5', 'M15', 'H1', 'H4', 'D1', 'W1']

    # Output naming
    MODEL_PREFIX = "ai_predict_randomforest"
    MODEL_EXT = ".joblib"       # scikit-learn model via joblib
    METADATA_EXT = ".pkl"

    # UI settings
    APP_TITLE = "🌲 Random Forest Model Trainer"
    APP_GEOMETRY = "640x1150"
    THEME = "dark"
    COLOR_THEME = "dark-blue"

    @classmethod
    def ensure_directories(cls):
        cls.MODEL_DIR.mkdir(parents=True, exist_ok=True)
        cls.DATASET_DIR.mkdir(parents=True, exist_ok=True)


Config.ensure_directories()

# ===== CTK Theme Settings =====
ctk.set_appearance_mode(Config.THEME)
ctk.set_default_color_theme(Config.COLOR_THEME)

# ===== Constants =====
HOME = Config.HOME
MODEL_DIR = Config.MODEL_DIR
DATASET_DIR = Config.DATASET_DIR


# ===== GPU Manager =====
class GPUManager:
    """
    Detects an NVIDIA GPU via nvidia-smi, and separately checks whether
    RAPIDS cuML is installed. Plain scikit-learn's RandomForestRegressor is
    CPU-only, but cuML's RandomForestRegressor is a (mostly) drop-in,
    GPU-accelerated replacement. We only report GPU as usable when BOTH
    a GPU is present AND cuML can be imported - otherwise we transparently
    fall back to CPU training with scikit-learn.
    """

    def __init__(self, verbose=True):
        self.verbose = verbose
        self.gpu_available = False
        self.gpu_name = None
        self.cuml_available = False
        self._detect_gpu()
        self._detect_cuml()

    def _log(self, message):
        if self.verbose:
            print(f"[GPUManager] {message}")

    def _detect_gpu(self):
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                self.gpu_available = True
                self.gpu_name = result.stdout.strip().splitlines()[0]
                self._log(f"✅ GPU detected: {self.gpu_name}")
            else:
                self._log("ℹ️ No GPU detected, using CPU")
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
            self.gpu_available = False
            self._log("ℹ️ No GPU detected, using CPU")

    def _detect_cuml(self):
        if not self.gpu_available:
            return
        try:
            import cuml  # noqa: F401
            self.cuml_available = True
            self._log("✅ cuML found - Random Forest will train on GPU")
        except ImportError:
            self.cuml_available = False
            self._log(
                "⚠️ GPU present but cuML not installed - falling back to CPU. "
                "Install RAPIDS cuML (https://rapids.ai) to enable GPU training."
            )

    def task_type(self):
        return "GPU" if (self.gpu_available and self.cuml_available) else "CPU"


# ===== Usage Row Class =====
class UsageRow:
    """System usage monitoring row for the GUI"""

    def __init__(self, parent):
        self.parent = parent
        self.usage_frame = None
        self.usage_label = None
        self._create_usage_row()

    def _create_usage_row(self):
        self.usage_frame = CTkFrame(self.parent, height=40, corner_radius=5)
        self.usage_frame.pack(fill="x", pady=(0, 10))

        self.usage_label = CTkLabel(
            self.usage_frame,
            text="Loading system usage...",
            font=("Ubuntu Mono", 20),
            text_color="Lime"
        )
        self.usage_label.pack(expand=True, fill="x", padx=10, pady=5)

        self._update_usage()

    def _update_usage(self):
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            dram = psutil.virtual_memory().percent

            gpu_percent = 0
            vram_percent = 0
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_percent = gpu.load * 100
                    vram_percent = gpu.memoryUtil * 100
            except (ImportError, Exception):
                pass

            self.usage_label.configure(
                text=f"CPU: {cpu:.1f}%  DRAM: {dram:.1f}%  GPU: {gpu_percent:.1f}%  VRAM: {vram_percent:.1f}%"
            )
        except Exception:
            self.usage_label.configure(text="⚠️ System monitoring unavailable")

        self.usage_label.after(2000, self._update_usage)


# ===== Console Logger =====
class ConsoleLogger:
    def __init__(self, gui_logger, original_stream):
        self.gui_logger = gui_logger
        self.original_stream = original_stream

    def write(self, message):
        if message and message.strip():
            self.original_stream.write(message)
            self.original_stream.flush()
            if self.gui_logger:
                self.gui_logger.log(message.strip(), "console")

    def flush(self):
        self.original_stream.flush()


# ===== Memory Optimizer =====
class MemoryOptimizer:
    @staticmethod
    def get_system_memory_gb():
        return psutil.virtual_memory().total / 1e9

    @staticmethod
    def get_system_memory_available_gb():
        return psutil.virtual_memory().available / 1e9

    @staticmethod
    def clear_cache():
        gc.collect()

    @staticmethod
    def monitor_memory(threshold_gb=0.5):
        return MemoryOptimizer.get_system_memory_available_gb() < threshold_gb


# ===== Feature Engineer =====
class FeatureEngineer:
    """Extract time-based and technical features"""

    @staticmethod
    def add_time_features(df):
        if 'time' not in df.columns:
            return df

        if not pd.api.types.is_datetime64_any_dtype(df['time']):
            df['time'] = pd.to_datetime(df['time'])

        df['hour'] = df['time'].dt.hour
        df['day_of_week'] = df['time'].dt.dayofweek
        df['day_of_month'] = df['time'].dt.day
        df['month'] = df['time'].dt.month
        df['quarter'] = df['time'].dt.quarter
        df['year'] = df['time'].dt.year

        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)

        return df

    @staticmethod
    def add_technical_features(df):
        if all(c in df.columns for c in ['high', 'low', 'close']):
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_high_ratio'] = df['close'] / df['high']
            df['close_low_ratio'] = df['close'] / df['low']

        if 'close' in df.columns:
            df['returns_1'] = df['close'].pct_change()
            df['returns_5'] = df['close'].pct_change(periods=5)
            df['returns_10'] = df['close'].pct_change(periods=10)

        if 'volume' in df.columns:
            df['volume_ma_5'] = df['volume'].rolling(5).mean()
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(5).mean()

        return df


class GUILogger:
    def __init__(self):
        self.messages = []
        self.log_widget = None
        self.ready = False
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr

    def set_log_widget(self, widget):
        self.log_widget = widget
        self.ready = True
        self.log_widget.configure(font=("Ubuntu Mono", 11))
        for msg, level in self.messages:
            self._write_to_widget(msg, level)
        self.messages.clear()

    def _write_to_widget(self, message, level):
        if self.log_widget:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {message}\n"
            try:
                self.log_widget.insert("end", log_entry)
                self.log_widget.see("end")
                self.log_widget.update_idletasks()
            except Exception:
                print(log_entry, flush=True)

    def log(self, message, level="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_entry = f"[{timestamp}] [{level.upper()}] {message}"
        try:
            self._original_stdout.write(console_entry + "\n")
            self._original_stdout.flush()
        except Exception:
            print(console_entry, flush=True)
        if self.ready and self.log_widget:
            self._write_to_widget(message, level)
        else:
            self.messages.append((message, level))

    def enable_console_redirect(self):
        sys.stdout = ConsoleLogger(self, self._original_stdout)
        sys.stderr = ConsoleLogger(self, self._original_stderr)

    def disable_console_redirect(self):
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr


class StreamingDataPreparer:
    """Builds an RF-ready tabular dataframe, one timeframe at a time."""

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print
        self.feature_cols = []
        self.categorical_features = ["group_id"]
        self.target_column = "target"

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def load_csv_data(self, symbol, timeframe, csv_folder):
        csv_file = Path(csv_folder) / symbol / f"{symbol}_{timeframe}.csv"

        if not csv_file.exists():
            return None

        try:
            df = pd.read_csv(csv_file)

            if "time" not in df.columns:
                self._log(f"⚠️ Missing time column: {csv_file}")
                return None

            if pd.api.types.is_numeric_dtype(df["time"]):
                df["time"] = pd.to_datetime(df["time"], unit="s")
            else:
                df["time"] = pd.to_datetime(df["time"])

            df = (
                df.sort_values("time")
                .drop_duplicates("time")
                .reset_index(drop=True)
            )

            return df

        except Exception as exc:
            self._log(f"❌ Error loading {csv_file}: {exc}")
            return None

    def scan_folder(self, csv_folder):
        csv_folder = Path(csv_folder)

        if not csv_folder.exists():
            return [], []

        symbols = []
        all_timeframes = set()

        for symbol_dir in sorted(csv_folder.iterdir()):
            if not symbol_dir.is_dir():
                continue

            symbol = symbol_dir.name
            found_timeframes = []

            for timeframe in Config.TIMEFRAMES:
                csv_file = symbol_dir / f"{symbol}_{timeframe}.csv"

                if csv_file.exists():
                    found_timeframes.append(timeframe)
                    all_timeframes.add(timeframe)

            if found_timeframes:
                symbols.append((symbol, found_timeframes))
                self._log(f"   ✓ {symbol}: {', '.join(found_timeframes)}")

        return symbols, sorted(all_timeframes)

    def _prepare_single_series(self, df, symbol, horizon, requested_features):
        if df is None or len(df) < 100:
            return None

        df = df.copy()

        if len(df) > Config.MAX_ROWS_PER_SYMBOL:
            df = df.iloc[-Config.MAX_ROWS_PER_SYMBOL:].copy()

        df = FeatureEngineer.add_time_features(df)
        df = FeatureEngineer.add_technical_features(df)

        requested_features = [c for c in requested_features if c != "time"]

        engineered_features = [
            "hour_sin", "hour_cos", "day_sin", "day_cos",
            "month_sin", "month_cos",
            "high_low_ratio", "close_high_ratio", "close_low_ratio",
            "returns_1", "returns_5", "returns_10", "volume_ratio",
        ]

        candidate_features = list(dict.fromkeys(requested_features + engineered_features))
        available_features = [c for c in candidate_features if c in df.columns]

        required_columns = ["open", "high", "low", "close", "volume"]
        for column in required_columns:
            if column in df.columns and column not in available_features:
                available_features.append(column)

        if "close" not in df.columns:
            self._log(f"⚠️ Skipping {symbol}: close column unavailable")
            return None

        if not available_features:
            self._log(f"⚠️ Skipping {symbol}: no usable features")
            return None

        df[available_features] = (
            df[available_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
        )

        df[self.target_column] = df["close"].shift(-horizon)
        df = df.dropna(subset=[self.target_column]).copy()

        if len(df) < 50:
            return None

        df["group_id"] = str(symbol)
        df["time_idx"] = np.arange(len(df), dtype=np.int64)

        keep_columns = ["time", "time_idx", "group_id", self.target_column] + available_features
        return df[keep_columns], available_features

    def build_dataframe_for_timeframe(self, csv_folder, feature_cols, horizon, timeframe):
        """
        Build one combined dataframe for a SINGLE timeframe, stacking every
        symbol that has that timeframe available. 'group_id' (the symbol)
        is kept as a feature (label-encoded for RF) so one model can
        generalize across instruments for that timeframe.
        """
        csv_folder = Path(csv_folder)
        symbols, _ = self.scan_folder(csv_folder)

        symbols_with_tf = [s for s, tfs in symbols if timeframe in tfs]

        if not symbols_with_tf:
            raise ValueError(f"No symbols found with timeframe {timeframe} in {csv_folder}")

        frames = []
        all_features = []

        for symbol in symbols_with_tf:
            df = self.load_csv_data(symbol, timeframe, csv_folder)
            prepared = self._prepare_single_series(df, symbol, horizon, feature_cols)

            if prepared is None:
                continue

            prepared_df, available_features = prepared
            frames.append(prepared_df)
            all_features.extend(available_features)

            self._log(f"   📊 {symbol}_{timeframe}: {len(prepared_df)} rows")

        if not frames:
            raise ValueError(f"No usable series produced for timeframe {timeframe}")

        all_features = list(dict.fromkeys(all_features))
        result = pd.concat(frames, ignore_index=True, sort=False)

        for column in all_features:
            if column not in result.columns:
                result[column] = 0.0

        result[all_features] = (
            result[all_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
            .astype(np.float32)
        )

        result[self.target_column] = (
            result[self.target_column]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .astype(np.float32)
        )

        result = result.sort_values(["group_id", "time_idx"]).reset_index(drop=True)

        self.feature_cols = all_features
        self._log(f"✅ [{timeframe}] Prepared {len(result):,} rows, {result['group_id'].nunique()} symbols")
        self._log(f"✅ [{timeframe}] Numeric features: {len(self.feature_cols)}")

        return result


class StreamingRFTrainer:
    """
    Trains one independent RandomForestRegressor per timeframe.
    Each call to train_single_timeframe() produces one model.
    """

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print

        self.gpu_manager = GPUManager(verbose=False)

        self.model = None
        self.label_encoder = None
        self.is_trained = False
        self.stop_flag = False

        self.n_estimators = Config.DEFAULT_N_ESTIMATORS
        self.max_depth = Config.DEFAULT_MAX_DEPTH
        self.min_samples_leaf = Config.DEFAULT_MIN_SAMPLES_LEAF

        self.training_history = {}

        self._log(f"🌲 Random Forest trainer initialized on: {self.gpu_manager.task_type()}")

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def stop_training(self):
        # NOTE: sklearn's RandomForestRegressor.fit() is atomic - it cannot be
        # interrupted mid-fit like CatBoost's iteration callback. This flag is
        # only checked between timeframes in the GUI's training loop.
        self.stop_flag = True
        self._log("⏹️ Training stop requested (will halt after current timeframe)")

    def _chronological_split(self, data):
        """Reserve the last VALIDATION_FRACTION of each symbol's rows for validation."""
        train_parts, val_parts = [], []

        for _, group in data.groupby("group_id"):
            group = group.sort_values("time_idx")
            n_val = max(1, int(len(group) * Config.VALIDATION_FRACTION))
            train_parts.append(group.iloc[:-n_val])
            val_parts.append(group.iloc[-n_val:])

        train_df = pd.concat(train_parts, ignore_index=True)
        val_df = pd.concat(val_parts, ignore_index=True)
        return train_df, val_df

    def train_single_timeframe(
        self,
        data,
        feature_cols,
        timeframe,
        n_estimators=300,
        max_depth=12,
        min_samples_leaf=5,
        **kwargs,
    ):
        """Train one RandomForestRegressor for a single timeframe's dataframe."""
        try:
            self.stop_flag = False

            if len(data) == 0:
                raise ValueError("Prepared dataframe is empty")

            train_df, val_df = self._chronological_split(data)

            if len(train_df) == 0 or len(val_df) == 0:
                raise ValueError("Train/validation split produced an empty set")

            # RandomForest needs numeric input -> label-encode the symbol column
            self.label_encoder = LabelEncoder()
            all_groups = pd.concat([train_df["group_id"], val_df["group_id"]])
            self.label_encoder.fit(all_groups)

            train_df = train_df.copy()
            val_df = val_df.copy()
            train_df["group_id_enc"] = self.label_encoder.transform(train_df["group_id"])
            val_df["group_id_enc"] = self.label_encoder.transform(val_df["group_id"])

            x_columns = feature_cols + ["group_id_enc"]

            x_train, y_train = train_df[x_columns], train_df["target"]
            x_val, y_val = val_df[x_columns], val_df["target"]

            self._log(f"📊 [{timeframe}] Training rows: {len(train_df):,}")
            self._log(f"📊 [{timeframe}] Validation rows: {len(val_df):,}")

            depth = None if not max_depth or max_depth <= 0 else max_depth

            self.model = RandomForestRegressor(
                n_estimators=n_estimators,
                max_depth=depth,
                min_samples_leaf=min_samples_leaf,
                n_jobs=-1,
                random_state=42,
                verbose=0,
            )

            self._log(f"🚀 [{timeframe}] Starting Random Forest training on CPU...")

            self.model.fit(x_train, y_train)

            val_pred = self.model.predict(x_val)
            val_rmse = float(np.sqrt(mean_squared_error(y_val, val_pred)))

            self.training_history = {
                "timeframe": timeframe,
                "n_estimators": n_estimators,
                "max_depth": depth,
                "min_samples_leaf": min_samples_leaf,
                "val_rmse": val_rmse,
                "train_rows": len(train_df),
                "val_rows": len(val_df),
            }

            self.is_trained = True

            self._log(f"🏁 [{timeframe}] Training complete (val_rmse={val_rmse:.6f})")

            return True

        except Exception as exc:
            self._log(f"❌ [{timeframe}] Training error: {exc}")
            traceback.print_exc()
            return False

    def save_model(self, model_dir, filename_stem, feature_cols, horizon, timeframe):
        """Save the RF model (.joblib) plus a metadata sidecar (.pkl)."""
        if not self.is_trained or self.model is None:
            self._log("⚠️ No trained model available")
            return False

        try:
            output_dir = Path(model_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            model_path = output_dir / f"{filename_stem}{Config.MODEL_EXT}"
            metadata_path = output_dir / f"{filename_stem}{Config.METADATA_EXT}"

            joblib.dump(self.model, model_path)

            metadata = {
                "model_type": "sklearn.ensemble.RandomForestRegressor",
                "timeframe": timeframe,
                "model_path": str(model_path),
                "feature_columns": feature_cols,  # excludes group_id_enc, appended at inference
                "categorical_features": ["group_id"],
                "label_encoder_classes": list(self.label_encoder.classes_) if self.label_encoder else [],
                "horizon": horizon,
                "training_history": self.training_history,
                "training_time": datetime.now().isoformat(),
            }

            with open(metadata_path, "wb") as file:
                pickle.dump(metadata, file)

            self._log(f"✅ RF model saved: {model_path}")
            self._log(f"✅ Metadata saved: {metadata_path}")

            return True

        except Exception as exc:
            self._log(f"❌ Save error: {exc}")
            traceback.print_exc()
            return False


class RFTrainerGUI(CTk):
    def __init__(self):
        super().__init__()

        self.title(Config.APP_TITLE)
        self.geometry(Config.APP_GEOMETRY)
        self.resizable(False, False)

        self.gui_logger = GUILogger()
        self.gui_logger.enable_console_redirect()

        self.csv_folder = Config.DATASET_DIR
        self.model_folder = Config.MODEL_DIR
        self.available_symbols = []
        self.available_timeframes = []
        self.is_training = False
        self.stop_flag = False

        self.data_preparer = StreamingDataPreparer(self.gui_logger.log)
        self.trainer = StreamingRFTrainer(self.gui_logger.log)

        self._create_ui()
        self.gui_logger.set_log_widget(self.log_text)
        self.after(500, self.scan_data_source)

        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _create_ui(self):
        main_frame = CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        title_frame = CTkFrame(main_frame, corner_radius=10)
        title_frame.pack(fill="x", pady=(0, 10))

        CTkLabel(title_frame, text="🎯 Random Forest Model Trainer (per timeframe)",
                 font=("Ubuntu", 18, "bold")).pack(pady=10)
        CTkLabel(title_frame, text="Copyright Su Nie | BSD-C-3 License | https://github.com/can87683",
                 font=("Ubuntu", 16), text_color="yellow").pack(pady=(0, 10))

        self.usage_row = UsageRow(main_frame)

        self._create_csv_section(main_frame)
        self._create_model_folder_section(main_frame)
        self._create_parameters_section(main_frame)
        self._create_features_section(main_frame)
        self._create_timeframes_section(main_frame)
        self._create_controls_section(main_frame)
        self._create_status_section(main_frame)
        self._create_log_section(main_frame)

    def _create_csv_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_csv_btn = CTkButton(folder_frame, text="📁 CSV Folder",
                                         command=self.select_csv_folder, width=140, height=32)
        self.select_csv_btn.pack(side="left", padx=(0, 10))

        self.csv_path_var = tk.StringVar(value=str(self.csv_folder))
        csv_entry = CTkEntry(folder_frame, textvariable=self.csv_path_var, state="readonly", height=32)
        csv_entry.pack(side="left", fill="x", expand=True)

    def _create_model_folder_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_model_btn = CTkButton(folder_frame, text="📁 Model Folder",
                                           command=self.select_model_folder, width=140, height=32)
        self.select_model_btn.pack(side="left", padx=(0, 10))

        self.model_path_var = tk.StringVar(value=str(self.model_folder))
        model_entry = CTkEntry(folder_frame, textvariable=self.model_path_var, state="readonly", height=32)
        model_entry.pack(side="left", fill="x", expand=True)

        self.status_label = CTkLabel(frame, text="📊 Status: No folder selected", font=("Ubuntu", 12))
        self.status_label.pack(anchor="w", padx=10, pady=5)

    def _create_parameters_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        param_frame = CTkFrame(frame, fg_color="transparent")
        param_frame.pack(fill="x", padx=10, pady=5)

        self.horizon = tk.StringVar(value=str(Config.DEFAULT_HORIZON))
        self.n_estimators = tk.StringVar(value=str(Config.DEFAULT_N_ESTIMATORS))
        self.min_samples_leaf = tk.StringVar(value=str(Config.DEFAULT_MIN_SAMPLES_LEAF))
        self.depth = tk.StringVar(value=str(Config.DEFAULT_MAX_DEPTH))

        row = CTkFrame(param_frame, fg_color="transparent")
        row.pack(fill="x", pady=2)

        for col in range(8):
            row.grid_columnconfigure(col, weight=1 if col % 2 else 0)

        CTkLabel(row, text="Horizon:", width=90).grid(row=0, column=0, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.horizon, width=80).grid(row=0, column=1, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Trees:", width=90).grid(row=0, column=2, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.n_estimators, width=80).grid(row=0, column=3, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Min Leaf:", width=90).grid(row=0, column=4, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.min_samples_leaf, width=80).grid(row=0, column=5, padx=(0, 15), sticky="w")

        CTkLabel(row, text="Depth (0=∞):", width=90).grid(row=0, column=6, padx=(0, 5), sticky="w")
        CTkEntry(row, textvariable=self.depth, width=80).grid(row=0, column=7, sticky="w")

    def _create_features_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        feature_frame = CTkFrame(frame, fg_color="transparent")
        feature_frame.pack(fill="x", padx=10, pady=5)

        default_features = "time,open,high,low,close,volume"
        self.feature_cols_var = tk.StringVar(value=default_features)

        CTkLabel(feature_frame, text="Base Features (comma-separated):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))
        feature_entry = CTkEntry(feature_frame, textvariable=self.feature_cols_var, height=32)
        feature_entry.pack(fill="x", pady=(0, 5))

    def _create_timeframes_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        tf_frame = CTkFrame(frame, fg_color="transparent")
        tf_frame.pack(fill="x", padx=10, pady=5)

        CTkLabel(tf_frame, text="Timeframes (one model each):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))

        self.tf_vars = {}
        checkboxes_frame = CTkFrame(tf_frame, fg_color="transparent")
        checkboxes_frame.pack(fill="x")

        for i, tf in enumerate(Config.TIMEFRAMES):
            var = tk.BooleanVar(value=True)
            self.tf_vars[tf] = var
            ctk.CTkCheckBox(checkboxes_frame, text=tf, variable=var, width=90).grid(
                row=0, column=i, padx=5, sticky="w"
            )

    def _create_controls_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        button_frame = CTkFrame(frame, fg_color="transparent")
        button_frame.pack(pady=10)

        self.train_btn = CTkButton(button_frame, text="🚀 Start Training",
                                    command=self.start_training, width=140, height=40,
                                    fg_color="#2e7d32", hover_color="#1b5e20",
                                    font=("Ubuntu", 13, "bold"))
        self.train_btn.pack(side="left", padx=5)

        self.stop_btn = CTkButton(button_frame, text="⏹️ Stop Training",
                                   command=self.stop_training, width=140, height=40,
                                   fg_color="#c62828", hover_color="#b71c1c",
                                   font=("Ubuntu", 13, "bold"), state="disabled")
        self.stop_btn.pack(side="left", padx=5)

    def _create_status_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        self.status_text = CTkTextbox(frame, height=80, font=("Ubuntu Mono", 11))
        self.status_text.pack(fill="x", padx=10, pady=5)
        self.status_text.insert("1.0", "Ready")
        self.status_text.configure(state="disabled")

    def _create_log_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="both", expand=True)

        self.log_text = CTkTextbox(frame, font=("Ubuntu Mono", 11))
        self.log_text.pack(fill="both", expand=True, padx=10, pady=5)

    def update_status(self, message):
        self.status_text.configure(state="normal")
        self.status_text.delete("1.0", "end")
        self.status_text.insert("1.0", message)
        self.status_text.configure(state="disabled")
        self.status_text.update_idletasks()

    def select_csv_folder(self):
        folder = filedialog.askdirectory(title="Select CSV Data Folder", initialdir=str(self.csv_folder))
        if folder:
            self.csv_path_var.set(folder)
            self.scan_data_source()

    def select_model_folder(self):
        folder = filedialog.askdirectory(title="Select Model Save Folder", initialdir=str(self.model_folder))
        if folder:
            self.model_path_var.set(folder)
            global MODEL_DIR
            MODEL_DIR = Path(folder)
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            self.gui_logger.log(f"💾 Model folder set to: {MODEL_DIR}")

    def scan_data_source(self):
        csv_folder = Path(self.csv_path_var.get())
        if not csv_folder.exists():
            self.gui_logger.log(f"❌ CSV folder not found: {csv_folder}", "error")
            self.status_label.configure(text="❌ Folder not found")
            self.train_btn.configure(state="disabled")
            return

        self.gui_logger.log(f"📁 Scanning CSV folder: {csv_folder}")
        symbols, timeframes = self.data_preparer.scan_folder(csv_folder)

        if not symbols:
            self.gui_logger.log("⚠️ No symbols found", "warning")
            self.status_label.configure(text="⚠️ No symbols found")
            self.train_btn.configure(state="disabled")
            return

        self.available_symbols = [s[0] for s in symbols]
        self.available_timeframes = timeframes

        self.status_label.configure(text=f"✅ Found {len(symbols)} symbols, {len(timeframes)} timeframes")
        self.gui_logger.log(f"✅ Loaded {len(symbols)} symbols", "success")
        self.train_btn.configure(state="normal")

    def start_training(self):
        if self.is_training:
            self.gui_logger.log("⏳ Training already in progress", "warning")
            return

        csv_folder = self.csv_path_var.get()
        if not Path(csv_folder).exists():
            self.gui_logger.log("❌ Invalid CSV folder", "error")
            return

        selected_timeframes = [tf for tf, var in self.tf_vars.items() if var.get()]
        if not selected_timeframes:
            self.gui_logger.log("❌ Select at least one timeframe", "error")
            return

        self.is_training = True
        self.stop_flag = False
        self.train_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        def training_task():
            try:
                self.gui_logger.log("=" * 60)
                self.gui_logger.log("🚀 Starting Per-Timeframe Random Forest Training")
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"📂 CSV Folder: {csv_folder}")
                self.gui_logger.log(
                    f"💾 System RAM: {MemoryOptimizer.get_system_memory_available_gb():.1f} GB available"
                )

                feature_input = self.feature_cols_var.get().strip()
                if feature_input:
                    feature_cols = [f.strip() for f in feature_input.split(',') if f.strip()]
                else:
                    feature_cols = Config.DEFAULT_FEATURES

                horizon = int(self.horizon.get())
                n_estimators = int(self.n_estimators.get())
                min_samples_leaf = int(self.min_samples_leaf.get())
                depth = int(self.depth.get())

                model_folder = self.model_path_var.get()

                results = {}

                for timeframe in selected_timeframes:
                    if self.stop_flag:
                        self.gui_logger.log("⏹️ Training stopped by user", "warning")
                        break

                    self.gui_logger.log("-" * 60)
                    self.gui_logger.log(f"▶️ Timeframe: {timeframe}")
                    self.update_status(f"[{timeframe}] Building dataset...")

                    try:
                        data = self.data_preparer.build_dataframe_for_timeframe(
                            csv_folder=csv_folder,
                            feature_cols=feature_cols,
                            horizon=horizon,
                            timeframe=timeframe,
                        )
                    except ValueError as exc:
                        self.gui_logger.log(f"⚠️ [{timeframe}] Skipped: {exc}", "warning")
                        results[timeframe] = "skipped (no data)"
                        continue

                    feature_columns = self.data_preparer.feature_cols

                    self.update_status(f"[{timeframe}] Training Random Forest model...")

                    success = self.trainer.train_single_timeframe(
                        data=data,
                        feature_cols=feature_columns,
                        timeframe=timeframe,
                        n_estimators=n_estimators,
                        max_depth=depth,
                        min_samples_leaf=min_samples_leaf,
                    )

                    if success:
                        filename_stem = f"{Config.MODEL_PREFIX}_{timeframe}"
                        if self.trainer.save_model(
                            model_dir=model_folder,
                            filename_stem=filename_stem,
                            feature_cols=feature_columns,
                            horizon=horizon,
                            timeframe=timeframe,
                        ):
                            self.gui_logger.log(f"✅ [{timeframe}] Model saved: {filename_stem}{Config.MODEL_EXT}", "success")
                            results[timeframe] = "trained"
                        else:
                            results[timeframe] = "failed to save"
                    else:
                        results[timeframe] = "training failed"

                summary = ", ".join(f"{tf}: {status}" for tf, status in results.items())
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"🏁 Summary: {summary}")
                self.update_status(f"Done. {summary}")

            except Exception as e:
                self.gui_logger.log(f"❌ Training error: {e}", "error")
                traceback.print_exc()
                self.update_status(f"Error: {e}")
            finally:
                self.is_training = False
                self.train_btn.configure(state="normal")
                self.stop_btn.configure(state="disabled")

        threading.Thread(target=training_task, daemon=True).start()

    def stop_training(self):
        self.stop_flag = True
        self.trainer.stop_training()
        self.gui_logger.log("⏹️ Stopping training (after current timeframe finishes)...", "warning")

    def _on_closing(self):
        self.gui_logger.disable_console_redirect()
        if self.is_training:
            result = messagebox.askyesno(
                "Training in Progress",
                "Training is currently running.\n\nDo you want to stop training and quit?",
                icon='warning',
            )
            if result:
                self.stop_flag = True
                self.trainer.stop_training()
                self.after(100, self.destroy)
        else:
            result = messagebox.askyesno("Quit", "Do you want to quit AI Predict Train (Random Forest)?")
            if result:
                self.destroy()


def main():
    app = RFTrainerGUI()
    app.mainloop()


if __name__ == "__main__":
    main()