#!/usr/bin/env python3
# ai_predict_train_gru_ctk.py
# Copyright Su Nie | BSD-C-3 License | https://github.com/can87683

import setproctitle
setproctitle.setproctitle("ai_predict_train_gru_ctk")

import customtkinter as ctk
from customtkinter import CTk, CTkFrame, CTkLabel, CTkButton, CTkEntry, CTkTextbox
import tkinter as tk
from tkinter import filedialog, messagebox
import threading
import subprocess
import copy
from pathlib import Path
import numpy as np
import pandas as pd
import pickle
import json
import gc
import psutil
from datetime import datetime
import traceback
import sys
import os
import time
import warnings

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

# Suppress FutureWarnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)


# ===== Configuration Class =====
class Config:
    """Central configuration for all settings"""

    # Paths
    HOME = Path.home()
    MODEL_DIR = HOME / "ai_models"
    DATASET_DIR = HOME / "mt5_data"

    # Data settings
    MAX_ROWS_PER_SYMBOL = 5000
    MAX_DATASET_ROWS = 100000
    DEFAULT_FEATURES = ['time', 'open', 'high', 'low', 'close', 'volume']

    # Model settings (GRU)
    DEFAULT_HORIZON = 10
    DEFAULT_SEQUENCE_LENGTH = 30        # lookback window fed to the GRU
    DEFAULT_EPOCHS = 100
    DEFAULT_LEARNING_RATE = 0.001
    DEFAULT_HIDDEN_SIZE = 64
    DEFAULT_NUM_LAYERS = 2
    DEFAULT_DROPOUT = 0.2
    DEFAULT_EMBEDDING_DIM = 8           # per-symbol embedding size
    DEFAULT_BATCH_SIZE = 128
    GRADIENT_CLIP_NORM = 5.0

    # Training settings
    EARLY_STOPPING_PATIENCE = 10        # epochs without val improvement
    VALIDATION_FRACTION = 0.15          # last X% of each symbol's series, chronologically

    # Memory settings
    MEMORY_WARNING_THRESHOLD_GB = 0.5

    # Timeframes -> one independent model is trained per timeframe
    TIMEFRAMES = ['M5', 'M15', 'H1', 'H4', 'D1', 'W1']

    # Output naming
    MODEL_PREFIX = "ai_predict_gru"
    MODEL_EXT = ".pt"            # PyTorch state dict
    METADATA_EXT = ".pkl"

    # UI settings
    APP_TITLE = "🚀 GRU Model Trainer"
    APP_GEOMETRY = "640x1250"
    THEME = "dark"
    COLOR_THEME = "dark-blue"

    @classmethod
    def ensure_directories(cls):
        cls.MODEL_DIR.mkdir(parents=True, exist_ok=True)
        cls.DATASET_DIR.mkdir(parents=True, exist_ok=True)


Config.ensure_directories()

# ===== CTK Theme Settings =====
ctk.set_appearance_mode(Config.THEME)
ctk.set_default_color_theme(Config.COLOR_THEME)

# ===== Constants =====
HOME = Config.HOME
MODEL_DIR = Config.MODEL_DIR
DATASET_DIR = Config.DATASET_DIR

torch.manual_seed(42)


# ===== GPU Manager (PyTorch CUDA device selection with safe fallback) =====
class GPUManager:
    """
    Detects an NVIDIA GPU via nvidia-smi for informational logging, then
    relies on torch.cuda.is_available() as the authoritative check for
    whether PyTorch can actually place tensors/model on the GPU. A CUDA
    RuntimeError at training start (bad driver mismatch, OOM, etc.) is
    caught by the trainer and results in an automatic, logged fallback to
    CPU, so GPU is used whenever it's genuinely usable.
    """

    def __init__(self, verbose=True):
        self.verbose = verbose
        self.gpu_available = False
        self.gpu_name = None
        self._detect_gpu()

        self.torch_cuda_available = torch.cuda.is_available()
        if self.torch_cuda_available:
            torch.backends.cudnn.benchmark = True

    def _log(self, message):
        if self.verbose:
            print(f"[GPUManager] {message}")

    def _detect_gpu(self):
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0 and result.stdout.strip():
                self.gpu_available = True
                self.gpu_name = result.stdout.strip().splitlines()[0]
                self._log(f"✅ GPU detected: {self.gpu_name}")
            else:
                self._log("ℹ️ No GPU detected, using CPU")
        except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
            self.gpu_available = False
            self._log("ℹ️ No GPU detected, using CPU")

    def preferred_devices(self):
        """Ordered list of torch.device candidates, most-preferred first."""
        if self.gpu_available and self.torch_cuda_available:
            return [torch.device("cuda"), torch.device("cpu")]
        return [torch.device("cpu")]


# ===== Usage Row Class =====
class UsageRow:
    """System usage monitoring row for the GUI"""

    def __init__(self, parent):
        self.parent = parent
        self.usage_frame = None
        self.usage_label = None
        self._create_usage_row()

    def _create_usage_row(self):
        self.usage_frame = CTkFrame(self.parent, height=40, corner_radius=5)
        self.usage_frame.pack(fill="x", pady=(0, 10))

        self.usage_label = CTkLabel(
            self.usage_frame,
            text="Loading system usage...",
            font=("Ubuntu Mono", 20),
            text_color="Lime"
        )
        self.usage_label.pack(expand=True, fill="x", padx=10, pady=5)

        self._update_usage()

    def _update_usage(self):
        try:
            cpu = psutil.cpu_percent(interval=0.5)
            dram = psutil.virtual_memory().percent

            gpu_percent = 0
            vram_percent = 0
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]
                    gpu_percent = gpu.load * 100
                    vram_percent = gpu.memoryUtil * 100
            except (ImportError, Exception):
                pass

            self.usage_label.configure(
                text=f"CPU: {cpu:.1f}%  DRAM: {dram:.1f}%  GPU: {gpu_percent:.1f}%  VRAM: {vram_percent:.1f}%"
            )
        except Exception:
            self.usage_label.configure(text="⚠️ System monitoring unavailable")

        self.usage_label.after(2000, self._update_usage)


# ===== Console Logger =====
class ConsoleLogger:
    def __init__(self, gui_logger, original_stream):
        self.gui_logger = gui_logger
        self.original_stream = original_stream

    def write(self, message):
        if message and message.strip():
            self.original_stream.write(message)
            self.original_stream.flush()
            if self.gui_logger:
                self.gui_logger.log(message.strip(), "console")

    def flush(self):
        self.original_stream.flush()


# ===== Memory Optimizer =====
class MemoryOptimizer:
    @staticmethod
    def get_system_memory_gb():
        return psutil.virtual_memory().total / 1e9

    @staticmethod
    def get_system_memory_available_gb():
        return psutil.virtual_memory().available / 1e9

    @staticmethod
    def clear_cache():
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    @staticmethod
    def monitor_memory(threshold_gb=0.5):
        return MemoryOptimizer.get_system_memory_available_gb() < threshold_gb


# ===== Feature Engineer =====
class FeatureEngineer:
    """Extract time-based and technical features"""

    @staticmethod
    def add_time_features(df):
        if 'time' not in df.columns:
            return df

        if not pd.api.types.is_datetime64_any_dtype(df['time']):
            df['time'] = pd.to_datetime(df['time'])

        df['hour'] = df['time'].dt.hour
        df['day_of_week'] = df['time'].dt.dayofweek
        df['day_of_month'] = df['time'].dt.day
        df['month'] = df['time'].dt.month
        df['quarter'] = df['time'].dt.quarter
        df['year'] = df['time'].dt.year

        df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
        df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
        df['day_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)

        return df

    @staticmethod
    def add_technical_features(df):
        if all(c in df.columns for c in ['high', 'low', 'close']):
            df['high_low_ratio'] = df['high'] / df['low']
            df['close_high_ratio'] = df['close'] / df['high']
            df['close_low_ratio'] = df['close'] / df['low']

        if 'close' in df.columns:
            df['returns_1'] = df['close'].pct_change()
            df['returns_5'] = df['close'].pct_change(periods=5)
            df['returns_10'] = df['close'].pct_change(periods=10)

        if 'volume' in df.columns:
            df['volume_ma_5'] = df['volume'].rolling(5).mean()
            df['volume_ratio'] = df['volume'] / df['volume'].rolling(5).mean()

        return df


class GUILogger:
    def __init__(self):
        self.messages = []
        self.log_widget = None
        self.ready = False
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr

    def set_log_widget(self, widget):
        self.log_widget = widget
        self.ready = True
        self.log_widget.configure(font=("Ubuntu Mono", 11))
        for msg, level in self.messages:
            self._write_to_widget(msg, level)
        self.messages.clear()

    def _write_to_widget(self, message, level):
        if self.log_widget:
            timestamp = datetime.now().strftime("%H:%M:%S")
            log_entry = f"[{timestamp}] {message}\n"
            try:
                self.log_widget.insert("end", log_entry)
                self.log_widget.see("end")
                self.log_widget.update_idletasks()
            except Exception:
                print(log_entry, flush=True)

    def log(self, message, level="info"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        console_entry = f"[{timestamp}] [{level.upper()}] {message}"
        try:
            self._original_stdout.write(console_entry + "\n")
            self._original_stdout.flush()
        except Exception:
            print(console_entry, flush=True)
        if self.ready and self.log_widget:
            self._write_to_widget(message, level)
        else:
            self.messages.append((message, level))

    def enable_console_redirect(self):
        sys.stdout = ConsoleLogger(self, self._original_stdout)
        sys.stderr = ConsoleLogger(self, self._original_stderr)

    def disable_console_redirect(self):
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr


class StreamingDataPreparer:
    """Builds a GRU-ready tabular dataframe, one timeframe at a time.

    Produces the same flat, one-row-per-timestep dataframe as before
    (engineered features + horizon-shifted target + integer group_id).
    Sequence windowing happens downstream in StreamingGRUTrainer, which
    slides a fixed-length lookback window over each symbol's rows.
    """

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print
        self.feature_cols = []
        self.categorical_features = ["group_id"]
        self.target_column = "target"

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def load_csv_data(self, symbol, timeframe, csv_folder):
        csv_file = Path(csv_folder) / symbol / f"{symbol}_{timeframe}.csv"

        if not csv_file.exists():
            return None

        try:
            df = pd.read_csv(csv_file)

            if "time" not in df.columns:
                self._log(f"⚠️ Missing time column: {csv_file}")
                return None

            if pd.api.types.is_numeric_dtype(df["time"]):
                df["time"] = pd.to_datetime(df["time"], unit="s")
            else:
                df["time"] = pd.to_datetime(df["time"])

            df = (
                df.sort_values("time")
                .drop_duplicates("time")
                .reset_index(drop=True)
            )

            return df

        except Exception as exc:
            self._log(f"❌ Error loading {csv_file}: {exc}")
            return None

    def scan_folder(self, csv_folder):
        csv_folder = Path(csv_folder)

        if not csv_folder.exists():
            return [], []

        symbols = []
        all_timeframes = set()

        for symbol_dir in sorted(csv_folder.iterdir()):
            if not symbol_dir.is_dir():
                continue

            symbol = symbol_dir.name
            found_timeframes = []

            for timeframe in Config.TIMEFRAMES:
                csv_file = symbol_dir / f"{symbol}_{timeframe}.csv"

                if csv_file.exists():
                    found_timeframes.append(timeframe)
                    all_timeframes.add(timeframe)

            if found_timeframes:
                symbols.append((symbol, found_timeframes))
                self._log(f"   ✓ {symbol}: {', '.join(found_timeframes)}")

        return symbols, sorted(all_timeframes)

    def _prepare_single_series(self, df, symbol, horizon, requested_features):
        if df is None or len(df) < 100:
            return None

        df = df.copy()

        if len(df) > Config.MAX_ROWS_PER_SYMBOL:
            df = df.iloc[-Config.MAX_ROWS_PER_SYMBOL:].copy()

        df = FeatureEngineer.add_time_features(df)
        df = FeatureEngineer.add_technical_features(df)

        requested_features = [c for c in requested_features if c != "time"]

        engineered_features = [
            "hour_sin", "hour_cos", "day_sin", "day_cos",
            "month_sin", "month_cos",
            "high_low_ratio", "close_high_ratio", "close_low_ratio",
            "returns_1", "returns_5", "returns_10", "volume_ratio",
        ]

        candidate_features = list(dict.fromkeys(requested_features + engineered_features))
        available_features = [c for c in candidate_features if c in df.columns]

        required_columns = ["open", "high", "low", "close", "volume"]
        for column in required_columns:
            if column in df.columns and column not in available_features:
                available_features.append(column)

        if "close" not in df.columns:
            self._log(f"⚠️ Skipping {symbol}: close column unavailable")
            return None

        if not available_features:
            self._log(f"⚠️ Skipping {symbol}: no usable features")
            return None

        df[available_features] = (
            df[available_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
        )

        df[self.target_column] = df["close"].shift(-horizon)
        df = df.dropna(subset=[self.target_column]).copy()

        if len(df) < 50:
            return None

        df["group_id"] = str(symbol)
        df["time_idx"] = np.arange(len(df), dtype=np.int64)

        keep_columns = ["time", "time_idx", "group_id", self.target_column] + available_features
        return df[keep_columns], available_features

    def build_dataframe_for_timeframe(self, csv_folder, feature_cols, horizon, timeframe):
        """
        Build one combined dataframe for a SINGLE timeframe, stacking every
        symbol that has that timeframe available. 'group_id' (the symbol)
        is encoded as an integer so the GRU can look it up in a per-symbol
        embedding table and generalize across instruments for that timeframe.
        """
        csv_folder = Path(csv_folder)
        symbols, _ = self.scan_folder(csv_folder)

        symbols_with_tf = [s for s, tfs in symbols if timeframe in tfs]

        if not symbols_with_tf:
            raise ValueError(f"No symbols found with timeframe {timeframe} in {csv_folder}")

        frames = []
        all_features = []

        for symbol in symbols_with_tf:
            df = self.load_csv_data(symbol, timeframe, csv_folder)
            prepared = self._prepare_single_series(df, symbol, horizon, feature_cols)

            if prepared is None:
                continue

            prepared_df, available_features = prepared
            frames.append(prepared_df)
            all_features.extend(available_features)

            self._log(f"   📊 {symbol}_{timeframe}: {len(prepared_df)} rows")

        if not frames:
            raise ValueError(f"No usable series produced for timeframe {timeframe}")

        all_features = list(dict.fromkeys(all_features))
        result = pd.concat(frames, ignore_index=True, sort=False)

        for column in all_features:
            if column not in result.columns:
                result[column] = 0.0

        result[all_features] = (
            result[all_features]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .fillna(0.0)
            .astype(np.float32)
        )

        result[self.target_column] = (
            result[self.target_column]
            .replace([np.inf, -np.inf], np.nan)
            .ffill()
            .bfill()
            .astype(np.float32)
        )

        # Map symbol name -> stable integer code (kept in metadata for inference)
        result["group_id"] = result["group_id"].astype("category")
        self.group_id_categories = list(result["group_id"].cat.categories)
        result["group_id"] = result["group_id"].cat.codes.astype(np.int64)

        result = result.sort_values(["group_id", "time_idx"]).reset_index(drop=True)

        self.feature_cols = all_features
        self._log(f"✅ [{timeframe}] Prepared {len(result):,} rows, {result['group_id'].nunique()} symbols")
        self._log(f"✅ [{timeframe}] Numeric features: {len(self.feature_cols)}")

        return result


# ===== Sequence dataset =====
class SequenceDataset(Dataset):
    """Wraps pre-built (N, seq_len, num_features) windows for a DataLoader."""

    def __init__(self, X, group_ids, y):
        self.X = torch.from_numpy(X)
        self.group_ids = torch.from_numpy(group_ids).long()
        self.y = torch.from_numpy(y)

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.X[idx], self.group_ids[idx], self.y[idx]


# ===== GRU model =====
class GRURegressor(nn.Module):
    """Per-symbol-embedding GRU regressor.

    A sliding window of engineered features is encoded by a multi-layer
    GRU; its final hidden state is concatenated with a learned embedding
    of the symbol (group_id) so a single model can generalize across
    instruments, then passed through a small MLP head to predict the
    horizon-shifted close price. GRU has no separate cell state (unlike
    LSTM) — just a single gated hidden state — giving ~25% fewer
    parameters than an LSTM of the same hidden_size, which trains faster
    and tends to overfit less on moderate-sized per-symbol datasets.
    """

    def __init__(self, num_features, hidden_size, num_layers, dropout, num_groups, embedding_dim):
        super().__init__()
        self.embedding = nn.Embedding(num_embeddings=max(num_groups, 1), embedding_dim=embedding_dim)
        self.gru = nn.GRU(
            input_size=num_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.head = nn.Sequential(
            nn.Linear(hidden_size + embedding_dim, max(hidden_size // 2, 8)),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(max(hidden_size // 2, 8), 1),
        )

    def forward(self, x_seq, group_ids):
        _, h_n = self.gru(x_seq)
        last_hidden = h_n[-1]                        # (batch, hidden_size)
        emb = self.embedding(group_ids)               # (batch, embedding_dim)
        combined = torch.cat([last_hidden, emb], dim=1)
        return self.head(combined).squeeze(-1)


class StreamingGRUTrainer:
    """
    Trains one independent GRURegressor per timeframe.
    Each call to train_single_timeframe() produces one model.
    """

    def __init__(self, log_callback=None):
        self.log_callback = log_callback or print

        self.gpu_manager = GPUManager(verbose=False)

        self.model = None
        self.is_trained = False
        self.stop_flag = False
        self.device_used = "cpu"

        self.sequence_length = Config.DEFAULT_SEQUENCE_LENGTH
        self.epochs = Config.DEFAULT_EPOCHS
        self.learning_rate = Config.DEFAULT_LEARNING_RATE
        self.hidden_size = Config.DEFAULT_HIDDEN_SIZE
        self.num_layers = Config.DEFAULT_NUM_LAYERS
        self.dropout = Config.DEFAULT_DROPOUT
        self.embedding_dim = Config.DEFAULT_EMBEDDING_DIM
        self.batch_size = Config.DEFAULT_BATCH_SIZE

        self.training_history = {}
        self.scaler_state = {}

        preferred = " -> ".join(str(d) for d in self.gpu_manager.preferred_devices())
        self._log(f"🚀 GRU trainer initialized. Device attempt order: {preferred.upper()}")

    def _log(self, message):
        if self.log_callback:
            self.log_callback(message)

    def stop_training(self):
        self.stop_flag = True
        self._log("⏹️ Training stop requested")

    def _chronological_split(self, data):
        """Reserve the last VALIDATION_FRACTION of each symbol's rows for validation."""
        train_parts, val_parts = [], []

        for _, group in data.groupby("group_id"):
            group = group.sort_values("time_idx")
            n_val = max(1, int(len(group) * Config.VALIDATION_FRACTION))
            train_parts.append(group.iloc[:-n_val])
            val_parts.append(group.iloc[-n_val:])

        train_df = pd.concat(train_parts, ignore_index=True)
        val_df = pd.concat(val_parts, ignore_index=True)
        return train_df, val_df

    def _fit_scalers(self, train_df, feature_cols):
        feature_mean = train_df[feature_cols].mean().to_numpy(dtype=np.float64)
        feature_std = train_df[feature_cols].std().replace(0, 1.0).to_numpy(dtype=np.float64)
        target_mean = float(train_df["target"].mean())
        target_std = float(train_df["target"].std()) or 1.0
        return {
            "feature_mean": feature_mean,
            "feature_std": feature_std,
            "target_mean": target_mean,
            "target_std": target_std,
        }

    def _apply_scalers(self, df, feature_cols, scaler_state):
        df = df.copy()
        df[feature_cols] = (df[feature_cols].to_numpy(dtype=np.float64) - scaler_state["feature_mean"]) / scaler_state["feature_std"]
        df["target"] = (df["target"].to_numpy(dtype=np.float64) - scaler_state["target_mean"]) / scaler_state["target_std"]
        return df

    def _build_sequences_for_group(self, group_df, feature_cols, seq_len, context_df=None):
        """
        Slide a fixed-length window over one symbol's rows. If context_df is
        given (e.g. the tail of the training rows), it is prepended so the
        first validation rows still get a full lookback window without
        crossing into future/unseen data.
        """
        if context_df is not None and len(context_df) > 0:
            combined = pd.concat([context_df, group_df], ignore_index=True)
            start_offset = len(context_df)
        else:
            combined = group_df
            start_offset = 0

        features = combined[feature_cols].to_numpy(dtype=np.float32)
        targets = combined["target"].to_numpy(dtype=np.float32)
        n = len(combined)

        if n < seq_len:
            return None

        first_target_idx = max(seq_len - 1, start_offset)
        X_list, y_list = [], []
        for i in range(first_target_idx, n):
            X_list.append(features[i - seq_len + 1: i + 1])
            y_list.append(targets[i])

        if not X_list:
            return None

        X = np.stack(X_list).astype(np.float32)
        y = np.array(y_list, dtype=np.float32)
        return X, y

    def _build_sequence_arrays(self, train_df, val_df, feature_cols, seq_len):
        X_train_list, y_train_list, g_train_list = [], [], []
        X_val_list, y_val_list, g_val_list = [], [], []

        train_groups = dict(tuple(train_df.groupby("group_id")))
        val_groups = dict(tuple(val_df.groupby("group_id")))

        for group_id, group_df in train_groups.items():
            group_df = group_df.sort_values("time_idx")
            built = self._build_sequences_for_group(group_df, feature_cols, seq_len)
            if built is None:
                continue
            X, y = built
            X_train_list.append(X)
            y_train_list.append(y)
            g_train_list.append(np.full(len(y), group_id, dtype=np.int64))

        for group_id, group_df in val_groups.items():
            group_df = group_df.sort_values("time_idx")
            context = train_groups.get(group_id)
            context_tail = context.sort_values("time_idx").iloc[-(seq_len - 1):] if context is not None else None
            built = self._build_sequences_for_group(group_df, feature_cols, seq_len, context_df=context_tail)
            if built is None:
                continue
            X, y = built
            X_val_list.append(X)
            y_val_list.append(y)
            g_val_list.append(np.full(len(y), group_id, dtype=np.int64))

        if not X_train_list:
            raise ValueError("No training sequences could be built (sequence_length too long for available rows)")

        X_train = np.concatenate(X_train_list)
        y_train = np.concatenate(y_train_list)
        g_train = np.concatenate(g_train_list)

        if X_val_list:
            X_val = np.concatenate(X_val_list)
            y_val = np.concatenate(y_val_list)
            g_val = np.concatenate(g_val_list)
        else:
            X_val, y_val, g_val = X_train[:0], y_train[:0], g_train[:0]

        return X_train, y_train, g_train, X_val, y_val, g_val

    def train_single_timeframe(
        self,
        data,
        feature_cols,
        timeframe,
        num_groups,
        epochs=100,
        learning_rate=0.001,
        sequence_length=30,
        hidden_size=64,
        num_layers=2,
        dropout=0.2,
        batch_size=128,
        status_callback=None,
        **kwargs,
    ):
        """Train one GRURegressor for a single timeframe's dataframe.

        Tries CUDA first (when available) and falls back to CPU automatically
        if placing the model/tensors on the GPU raises (driver mismatch, OOM,
        etc.), so a GPU is used whenever it's genuinely usable.
        """
        try:
            self.stop_flag = False

            if len(data) == 0:
                raise ValueError("Prepared dataframe is empty")

            train_df, val_df = self._chronological_split(data)

            if len(train_df) == 0:
                raise ValueError("Train split produced an empty set")

            scaler_state = self._fit_scalers(train_df, feature_cols)
            train_df = self._apply_scalers(train_df, feature_cols, scaler_state)
            val_df = self._apply_scalers(val_df, feature_cols, scaler_state) if len(val_df) else val_df

            X_train, y_train, g_train, X_val, y_val, g_val = self._build_sequence_arrays(
                train_df, val_df, feature_cols, sequence_length
            )

            self._log(f"📊 [{timeframe}] Training sequences: {len(y_train):,}")
            self._log(f"📊 [{timeframe}] Validation sequences: {len(y_val):,}")

            train_loader = DataLoader(
                SequenceDataset(X_train, g_train, y_train),
                batch_size=batch_size, shuffle=True, drop_last=False,
            )
            val_loader = None
            if len(y_val) > 0:
                val_loader = DataLoader(
                    SequenceDataset(X_val, g_val, y_val),
                    batch_size=batch_size, shuffle=False, drop_last=False,
                )

            last_error = None
            trained_ok = False

            for device in self.gpu_manager.preferred_devices():
                if self.stop_flag:
                    break

                self._log(f"🚀 [{timeframe}] Attempting training on device='{device}'...")

                try:
                    trained_ok = self._run_training_loop(
                        train_loader, val_loader,
                        num_features=len(feature_cols),
                        num_groups=num_groups,
                        hidden_size=hidden_size,
                        num_layers=num_layers,
                        dropout=dropout,
                        embedding_dim=self.embedding_dim,
                        epochs=epochs,
                        learning_rate=learning_rate,
                        device=device,
                        timeframe=timeframe,
                        status_callback=status_callback,
                    )
                    self.device_used = str(device)
                    break
                except RuntimeError as exc:
                    last_error = exc
                    self._log(f"⚠️ [{timeframe}] device='{device}' failed ({exc}); falling back...")
                    MemoryOptimizer.clear_cache()
                    continue

            if not trained_ok:
                raise last_error or RuntimeError("No device succeeded in training")

            self.scaler_state = scaler_state
            self.is_trained = True

            self._log(
                f"🏁 [{timeframe}] Training complete "
                f"(device={self.device_used}, best_epoch={self.training_history.get('best_epoch')}, "
                f"val_loss={self.training_history.get('best_val_loss')})"
            )

            return True

        except Exception as exc:
            self._log(f"❌ [{timeframe}] Training error: {exc}")
            traceback.print_exc()
            return False

    def _run_training_loop(
        self, train_loader, val_loader, num_features, num_groups,
        hidden_size, num_layers, dropout, embedding_dim,
        epochs, learning_rate, device, timeframe, status_callback,
    ):
        model = GRURegressor(
            num_features=num_features,
            hidden_size=hidden_size,
            num_layers=num_layers,
            dropout=dropout,
            num_groups=num_groups,
            embedding_dim=embedding_dim,
        ).to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        loss_fn = nn.MSELoss()

        best_val_loss = float("inf")
        best_state = copy.deepcopy(model.state_dict())
        best_epoch = 0
        patience_counter = 0

        for epoch in range(1, epochs + 1):
            if self.stop_flag:
                self._log(f"⏹️ [{timeframe}] Stopped at epoch {epoch}")
                break

            model.train()
            train_loss_sum, train_count = 0.0, 0
            for X_batch, g_batch, y_batch in train_loader:
                if self.stop_flag:
                    break
                X_batch = X_batch.to(device)
                g_batch = g_batch.to(device)
                y_batch = y_batch.to(device)

                optimizer.zero_grad()
                preds = model(X_batch, g_batch)
                loss = loss_fn(preds, y_batch)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), Config.GRADIENT_CLIP_NORM)
                optimizer.step()

                train_loss_sum += loss.item() * len(y_batch)
                train_count += len(y_batch)

            train_loss = train_loss_sum / max(train_count, 1)

            val_loss = train_loss
            if val_loader is not None:
                model.eval()
                val_loss_sum, val_count = 0.0, 0
                with torch.no_grad():
                    for X_batch, g_batch, y_batch in val_loader:
                        X_batch = X_batch.to(device)
                        g_batch = g_batch.to(device)
                        y_batch = y_batch.to(device)
                        preds = model(X_batch, g_batch)
                        loss = loss_fn(preds, y_batch)
                        val_loss_sum += loss.item() * len(y_batch)
                        val_count += len(y_batch)
                val_loss = val_loss_sum / max(val_count, 1)

            if status_callback:
                status_callback(f"[{timeframe}] Epoch {epoch}/{epochs}  train={train_loss:.5f}  val={val_loss:.5f}")

            if epoch == 1 or epoch % 5 == 0 or epoch == epochs:
                self._log(f"   📈 [{timeframe}] epoch {epoch}/{epochs}  train_loss={train_loss:.5f}  val_loss={val_loss:.5f}")

            if val_loss < best_val_loss - 1e-6:
                best_val_loss = val_loss
                best_state = copy.deepcopy(model.state_dict())
                best_epoch = epoch
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= Config.EARLY_STOPPING_PATIENCE:
                    self._log(f"⏹️ [{timeframe}] Early stopping at epoch {epoch} (best={best_epoch})")
                    break

        model.load_state_dict(best_state)
        model.eval()

        self.model = model
        self.training_history = {
            "timeframe": timeframe,
            "best_epoch": best_epoch,
            "best_val_loss": best_val_loss,
            "epochs_run": epoch,
        }
        return True

    def save_model(self, model_dir, filename_stem, feature_cols, horizon, timeframe,
                    num_groups, group_id_categories, sequence_length):
        """Save the GRU state dict (.pt) plus a metadata sidecar (.pkl) with
        everything needed to reconstruct and run the model at inference time."""
        if not self.is_trained or self.model is None:
            self._log("⚠️ No trained model available")
            return False

        try:
            output_dir = Path(model_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            model_path = output_dir / f"{filename_stem}{Config.MODEL_EXT}"
            metadata_path = output_dir / f"{filename_stem}{Config.METADATA_EXT}"

            torch.save(self.model.state_dict(), str(model_path))

            metadata = {
                "model_type": "torch.GRURegressor",
                "timeframe": timeframe,
                "model_path": str(model_path),
                "feature_columns": feature_cols,
                "categorical_features": ["group_id"],
                "group_id_categories": group_id_categories,
                "num_groups": num_groups,
                "sequence_length": sequence_length,
                "architecture": {
                    "num_features": len(feature_cols),
                    "hidden_size": self.hidden_size,
                    "num_layers": self.num_layers,
                    "dropout": self.dropout,
                    "embedding_dim": self.embedding_dim,
                },
                "scaler_state": self.scaler_state,
                "device_used": self.device_used,
                "horizon": horizon,
                "training_history": self.training_history,
                "training_time": datetime.now().isoformat(),
            }

            with open(metadata_path, "wb") as file:
                pickle.dump(metadata, file)

            self._log(f"✅ GRU model saved: {model_path}")
            self._log(f"✅ Metadata saved: {metadata_path}")

            return True

        except Exception as exc:
            self._log(f"❌ Save error: {exc}")
            traceback.print_exc()
            return False


class GRUTrainerGUI(CTk):
    def __init__(self):
        super().__init__()

        self.title(Config.APP_TITLE)
        self.geometry(Config.APP_GEOMETRY)
        self.resizable(False, False)

        self.gui_logger = GUILogger()
        self.gui_logger.enable_console_redirect()

        self.csv_folder = Config.DATASET_DIR
        self.model_folder = Config.MODEL_DIR
        self.available_symbols = []
        self.available_timeframes = []
        self.is_training = False
        self.stop_flag = False

        self.data_preparer = StreamingDataPreparer(self.gui_logger.log)
        self.trainer = StreamingGRUTrainer(self.gui_logger.log)

        self._create_ui()
        self.gui_logger.set_log_widget(self.log_text)
        self.after(500, self.scan_data_source)

        self.protocol("WM_DELETE_WINDOW", self._on_closing)

    def _create_ui(self):
        main_frame = CTkFrame(self, fg_color="transparent")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        title_frame = CTkFrame(main_frame, corner_radius=10)
        title_frame.pack(fill="x", pady=(0, 10))

        CTkLabel(title_frame, text="🎯 GRU Model Trainer (per timeframe)",
                 font=("Ubuntu", 18, "bold")).pack(pady=10)
        CTkLabel(title_frame, text="Copyright Su Nie | BSD-C-3 License | https://github.com/can87683",
                 font=("Ubuntu", 16), text_color="yellow").pack(pady=(0, 10))

        self.usage_row = UsageRow(main_frame)

        self._create_csv_section(main_frame)
        self._create_model_folder_section(main_frame)
        self._create_parameters_section(main_frame)
        self._create_features_section(main_frame)
        self._create_timeframes_section(main_frame)
        self._create_controls_section(main_frame)
        self._create_status_section(main_frame)
        self._create_log_section(main_frame)

    def _create_csv_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_csv_btn = CTkButton(folder_frame, text="📁 CSV Folder",
                                         command=self.select_csv_folder, width=140, height=32)
        self.select_csv_btn.pack(side="left", padx=(0, 10))

        self.csv_path_var = tk.StringVar(value=str(self.csv_folder))
        csv_entry = CTkEntry(folder_frame, textvariable=self.csv_path_var, state="readonly", height=32)
        csv_entry.pack(side="left", fill="x", expand=True)

    def _create_model_folder_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        folder_frame = CTkFrame(frame, fg_color="transparent")
        folder_frame.pack(fill="x", padx=10, pady=5)

        self.select_model_btn = CTkButton(folder_frame, text="📁 Model Folder",
                                           command=self.select_model_folder, width=140, height=32)
        self.select_model_btn.pack(side="left", padx=(0, 10))

        self.model_path_var = tk.StringVar(value=str(self.model_folder))
        model_entry = CTkEntry(folder_frame, textvariable=self.model_path_var, state="readonly", height=32)
        model_entry.pack(side="left", fill="x", expand=True)

        self.status_label = CTkLabel(frame, text="📊 Status: No folder selected", font=("Ubuntu", 12))
        self.status_label.pack(anchor="w", padx=10, pady=5)

    def _create_parameters_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        param_frame = CTkFrame(frame, fg_color="transparent")
        param_frame.pack(fill="x", padx=10, pady=5)

        self.horizon = tk.StringVar(value=str(Config.DEFAULT_HORIZON))
        self.epochs = tk.StringVar(value=str(Config.DEFAULT_EPOCHS))
        self.learning_rate = tk.StringVar(value=str(Config.DEFAULT_LEARNING_RATE))
        self.sequence_length = tk.StringVar(value=str(Config.DEFAULT_SEQUENCE_LENGTH))
        self.hidden_size = tk.StringVar(value=str(Config.DEFAULT_HIDDEN_SIZE))
        self.num_layers = tk.StringVar(value=str(Config.DEFAULT_NUM_LAYERS))
        self.batch_size = tk.StringVar(value=str(Config.DEFAULT_BATCH_SIZE))
        self.dropout = tk.StringVar(value=str(Config.DEFAULT_DROPOUT))

        row1 = CTkFrame(param_frame, fg_color="transparent")
        row1.pack(fill="x", pady=2)
        for col in range(8):
            row1.grid_columnconfigure(col, weight=1 if col % 2 else 0)

        CTkLabel(row1, text="Horizon:", width=90).grid(row=0, column=0, padx=(0, 5), sticky="w")
        CTkEntry(row1, textvariable=self.horizon, width=80).grid(row=0, column=1, padx=(0, 15), sticky="w")

        CTkLabel(row1, text="Epochs:", width=90).grid(row=0, column=2, padx=(0, 5), sticky="w")
        CTkEntry(row1, textvariable=self.epochs, width=80).grid(row=0, column=3, padx=(0, 15), sticky="w")

        CTkLabel(row1, text="LR:", width=90).grid(row=0, column=4, padx=(0, 5), sticky="w")
        CTkEntry(row1, textvariable=self.learning_rate, width=80).grid(row=0, column=5, padx=(0, 15), sticky="w")

        CTkLabel(row1, text="Seq Len:", width=90).grid(row=0, column=6, padx=(0, 5), sticky="w")
        CTkEntry(row1, textvariable=self.sequence_length, width=80).grid(row=0, column=7, sticky="w")

        row2 = CTkFrame(param_frame, fg_color="transparent")
        row2.pack(fill="x", pady=2)
        for col in range(8):
            row2.grid_columnconfigure(col, weight=1 if col % 2 else 0)

        CTkLabel(row2, text="Hidden:", width=90).grid(row=0, column=0, padx=(0, 5), sticky="w")
        CTkEntry(row2, textvariable=self.hidden_size, width=80).grid(row=0, column=1, padx=(0, 15), sticky="w")

        CTkLabel(row2, text="Layers:", width=90).grid(row=0, column=2, padx=(0, 5), sticky="w")
        CTkEntry(row2, textvariable=self.num_layers, width=80).grid(row=0, column=3, padx=(0, 15), sticky="w")

        CTkLabel(row2, text="Batch:", width=90).grid(row=0, column=4, padx=(0, 5), sticky="w")
        CTkEntry(row2, textvariable=self.batch_size, width=80).grid(row=0, column=5, padx=(0, 15), sticky="w")

        CTkLabel(row2, text="Dropout:", width=90).grid(row=0, column=6, padx=(0, 5), sticky="w")
        CTkEntry(row2, textvariable=self.dropout, width=80).grid(row=0, column=7, sticky="w")

    def _create_features_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        feature_frame = CTkFrame(frame, fg_color="transparent")
        feature_frame.pack(fill="x", padx=10, pady=5)

        default_features = "time,open,high,low,close,volume"
        self.feature_cols_var = tk.StringVar(value=default_features)

        CTkLabel(feature_frame, text="Base Features (comma-separated):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))
        feature_entry = CTkEntry(feature_frame, textvariable=self.feature_cols_var, height=32)
        feature_entry.pack(fill="x", pady=(0, 5))

    def _create_timeframes_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        tf_frame = CTkFrame(frame, fg_color="transparent")
        tf_frame.pack(fill="x", padx=10, pady=5)

        CTkLabel(tf_frame, text="Timeframes (one model each):", font=("Ubuntu", 12)).pack(anchor="w", pady=(0, 5))

        self.tf_vars = {}
        checkboxes_frame = CTkFrame(tf_frame, fg_color="transparent")
        checkboxes_frame.pack(fill="x")

        for i, tf in enumerate(Config.TIMEFRAMES):
            var = tk.BooleanVar(value=True)
            self.tf_vars[tf] = var
            ctk.CTkCheckBox(checkboxes_frame, text=tf, variable=var, width=90).grid(
                row=0, column=i, padx=5, sticky="w"
            )

    def _create_controls_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        button_frame = CTkFrame(frame, fg_color="transparent")
        button_frame.pack(pady=10)

        self.train_btn = CTkButton(button_frame, text="🚀 Start Training",
                                    command=self.start_training, width=140, height=40,
                                    fg_color="#2e7d32", hover_color="#1b5e20",
                                    font=("Ubuntu", 13, "bold"))
        self.train_btn.pack(side="left", padx=5)

        self.stop_btn = CTkButton(button_frame, text="⏹️ Stop Training",
                                   command=self.stop_training, width=140, height=40,
                                   fg_color="#c62828", hover_color="#b71c1c",
                                   font=("Ubuntu", 13, "bold"), state="disabled")
        self.stop_btn.pack(side="left", padx=5)

    def _create_status_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="x", pady=(0, 10))

        self.status_text = CTkTextbox(frame, height=80, font=("Ubuntu Mono", 11))
        self.status_text.pack(fill="x", padx=10, pady=5)
        self.status_text.insert("1.0", "Ready")
        self.status_text.configure(state="disabled")

    def _create_log_section(self, parent):
        frame = CTkFrame(parent, corner_radius=10)
        frame.pack(fill="both", expand=True)

        self.log_text = CTkTextbox(frame, font=("Ubuntu Mono", 11))
        self.log_text.pack(fill="both", expand=True, padx=10, pady=5)

    def update_status(self, message):
        self.status_text.configure(state="normal")
        self.status_text.delete("1.0", "end")
        self.status_text.insert("1.0", message)
        self.status_text.configure(state="disabled")
        self.status_text.update_idletasks()

    def select_csv_folder(self):
        folder = filedialog.askdirectory(title="Select CSV Data Folder", initialdir=str(self.csv_folder))
        if folder:
            self.csv_path_var.set(folder)
            self.scan_data_source()

    def select_model_folder(self):
        folder = filedialog.askdirectory(title="Select Model Save Folder", initialdir=str(self.model_folder))
        if folder:
            self.model_path_var.set(folder)
            global MODEL_DIR
            MODEL_DIR = Path(folder)
            MODEL_DIR.mkdir(parents=True, exist_ok=True)
            self.gui_logger.log(f"💾 Model folder set to: {MODEL_DIR}")

    def scan_data_source(self):
        csv_folder = Path(self.csv_path_var.get())
        if not csv_folder.exists():
            self.gui_logger.log(f"❌ CSV folder not found: {csv_folder}", "error")
            self.status_label.configure(text="❌ Folder not found")
            self.train_btn.configure(state="disabled")
            return

        self.gui_logger.log(f"📁 Scanning CSV folder: {csv_folder}")
        symbols, timeframes = self.data_preparer.scan_folder(csv_folder)

        if not symbols:
            self.gui_logger.log("⚠️ No symbols found", "warning")
            self.status_label.configure(text="⚠️ No symbols found")
            self.train_btn.configure(state="disabled")
            return

        self.available_symbols = [s[0] for s in symbols]
        self.available_timeframes = timeframes

        self.status_label.configure(text=f"✅ Found {len(symbols)} symbols, {len(timeframes)} timeframes")
        self.gui_logger.log(f"✅ Loaded {len(symbols)} symbols", "success")
        self.train_btn.configure(state="normal")

    def start_training(self):
        if self.is_training:
            self.gui_logger.log("⏳ Training already in progress", "warning")
            return

        csv_folder = self.csv_path_var.get()
        if not Path(csv_folder).exists():
            self.gui_logger.log("❌ Invalid CSV folder", "error")
            return

        selected_timeframes = [tf for tf, var in self.tf_vars.items() if var.get()]
        if not selected_timeframes:
            self.gui_logger.log("❌ Select at least one timeframe", "error")
            return

        self.is_training = True
        self.stop_flag = False
        self.train_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        def training_task():
            try:
                self.gui_logger.log("=" * 60)
                self.gui_logger.log("🚀 Starting Per-Timeframe GRU Training")
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"📂 CSV Folder: {csv_folder}")
                self.gui_logger.log(
                    f"💾 System RAM: {MemoryOptimizer.get_system_memory_available_gb():.1f} GB available"
                )

                feature_input = self.feature_cols_var.get().strip()
                if feature_input:
                    feature_cols = [f.strip() for f in feature_input.split(',') if f.strip()]
                else:
                    feature_cols = Config.DEFAULT_FEATURES

                horizon = int(self.horizon.get())
                epochs = int(self.epochs.get())
                learning_rate = float(self.learning_rate.get())
                sequence_length = int(self.sequence_length.get())
                hidden_size = int(self.hidden_size.get())
                num_layers = int(self.num_layers.get())
                batch_size = int(self.batch_size.get())
                dropout = float(self.dropout.get())

                self.trainer.hidden_size = hidden_size
                self.trainer.num_layers = num_layers
                self.trainer.dropout = dropout

                model_folder = self.model_path_var.get()

                results = {}

                for timeframe in selected_timeframes:
                    if self.stop_flag:
                        self.gui_logger.log("⏹️ Training stopped by user", "warning")
                        break

                    self.gui_logger.log("-" * 60)
                    self.gui_logger.log(f"▶️ Timeframe: {timeframe}")
                    self.update_status(f"[{timeframe}] Building dataset...")

                    try:
                        data = self.data_preparer.build_dataframe_for_timeframe(
                            csv_folder=csv_folder,
                            feature_cols=feature_cols,
                            horizon=horizon,
                            timeframe=timeframe,
                        )
                    except ValueError as exc:
                        self.gui_logger.log(f"⚠️ [{timeframe}] Skipped: {exc}", "warning")
                        results[timeframe] = "skipped (no data)"
                        continue

                    feature_columns = self.data_preparer.feature_cols
                    group_id_categories = self.data_preparer.group_id_categories
                    num_groups = len(group_id_categories)

                    self.update_status(f"[{timeframe}] Training GRU model...")

                    success = self.trainer.train_single_timeframe(
                        data=data,
                        feature_cols=feature_columns,
                        timeframe=timeframe,
                        num_groups=num_groups,
                        epochs=epochs,
                        learning_rate=learning_rate,
                        sequence_length=sequence_length,
                        hidden_size=hidden_size,
                        num_layers=num_layers,
                        dropout=dropout,
                        batch_size=batch_size,
                        status_callback=self.update_status,
                    )

                    if success and not self.trainer.stop_flag:
                        filename_stem = f"{Config.MODEL_PREFIX}_{timeframe}"
                        if self.trainer.save_model(
                            model_dir=model_folder,
                            filename_stem=filename_stem,
                            feature_cols=feature_columns,
                            horizon=horizon,
                            timeframe=timeframe,
                            num_groups=num_groups,
                            group_id_categories=group_id_categories,
                            sequence_length=sequence_length,
                        ):
                            self.gui_logger.log(f"✅ [{timeframe}] Model saved: {filename_stem}{Config.MODEL_EXT}", "success")
                            results[timeframe] = f"trained ({self.trainer.device_used})"
                        else:
                            results[timeframe] = "failed to save"
                    elif self.trainer.stop_flag:
                        results[timeframe] = "stopped"
                        self.stop_flag = True
                    else:
                        results[timeframe] = "training failed"

                summary = ", ".join(f"{tf}: {status}" for tf, status in results.items())
                self.gui_logger.log("=" * 60)
                self.gui_logger.log(f"🏁 Summary: {summary}")
                self.update_status(f"Done. {summary}")

            except Exception as e:
                self.gui_logger.log(f"❌ Training error: {e}", "error")
                traceback.print_exc()
                self.update_status(f"Error: {e}")
            finally:
                self.is_training = False
                self.train_btn.configure(state="normal")
                self.stop_btn.configure(state="disabled")

        threading.Thread(target=training_task, daemon=True).start()

    def stop_training(self):
        self.stop_flag = True
        self.trainer.stop_training()
        self.gui_logger.log("⏹️ Stopping training...", "warning")

    def _on_closing(self):
        self.gui_logger.disable_console_redirect()
        if self.is_training:
            result = messagebox.askyesno(
                "Training in Progress",
                "Training is currently running.\n\nDo you want to stop training and quit?",
                icon='warning',
            )
            if result:
                self.stop_flag = True
                self.trainer.stop_training()
                self.after(100, self.destroy)
        else:
            result = messagebox.askyesno("Quit", "Do you want to quit AI Predict Train (GRU)?")
            if result:
                self.destroy()


def main():
    app = GRUTrainerGUI()
    app.mainloop()


if __name__ == "__main__":
    main()